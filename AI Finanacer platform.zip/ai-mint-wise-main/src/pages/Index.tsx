const Index = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-8">
      <div className="mx-auto max-w-4xl">
        <div className="text-center mb-8">
          <h1 className="text-5xl font-bold text-primary mb-4">
            AI-Based Personal Finance Manager
          </h1>
          <p className="text-xl text-muted-foreground mb-6">
            Take control of your finances with AI-powered insights
          </p>
          <div className="inline-block bg-yellow-100 border border-yellow-400 rounded-lg p-4 text-yellow-800">
            <h2 className="font-semibold mb-2">🔧 Setup Required</h2>
            <p className="text-sm">
              To enable authentication, database, and AI features, please connect to Supabase using the green button in the top right.
            </p>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div className="bg-card rounded-lg p-6 shadow-sm border">
            <h3 className="font-semibold text-lg mb-2">💰 Expense Tracking</h3>
            <p className="text-muted-foreground text-sm">
              Add, edit, and categorize your expenses with detailed insights
            </p>
          </div>
          
          <div className="bg-card rounded-lg p-6 shadow-sm border">
            <h3 className="font-semibold text-lg mb-2">📊 Smart Analytics</h3>
            <p className="text-muted-foreground text-sm">
              Visualize spending patterns with interactive charts and graphs
            </p>
          </div>
          
          <div className="bg-card rounded-lg p-6 shadow-sm border">
            <h3 className="font-semibold text-lg mb-2">🎯 Budget Management</h3>
            <p className="text-muted-foreground text-sm">
              Set budgets and get notifications before exceeding limits
            </p>
          </div>
          
          <div className="bg-card rounded-lg p-6 shadow-sm border">
            <h3 className="font-semibold text-lg mb-2">🤖 AI Recommendations</h3>
            <p className="text-muted-foreground text-sm">
              Get personalized saving tips and investment advice
            </p>
          </div>
          
          <div className="bg-card rounded-lg p-6 shadow-sm border">
            <h3 className="font-semibold text-lg mb-2">🔒 Secure Authentication</h3>
            <p className="text-muted-foreground text-sm">
              JWT-based authentication to keep your data safe
            </p>
          </div>
          
          <div className="bg-card rounded-lg p-6 shadow-sm border">
            <h3 className="font-semibold text-lg mb-2">📱 Responsive Design</h3>
            <p className="text-muted-foreground text-sm">
              Beautiful interface that works on all devices
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Index;
