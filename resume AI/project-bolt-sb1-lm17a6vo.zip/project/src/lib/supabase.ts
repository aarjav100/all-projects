import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables')
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Database types
export interface Profile {
  id: string
  user_id: string
  email?: string
  full_name?: string
  phone?: string
  location?: string
  professional_title?: string
  summary?: string
  avatar_url?: string
  linkedin_url?: string
  github_url?: string
  website_url?: string
  created_at: string
  updated_at: string
}

export interface Resume {
  id: string
  user_id: string
  title: string
  template_id: string
  content: any
  is_public: boolean
  created_at: string
  updated_at: string
}

export interface Experience {
  id: string
  user_id: string
  resume_id?: string
  title: string
  company: string
  location?: string
  start_date?: string
  end_date?: string
  is_current: boolean
  description?: string
  achievements?: string[]
  technologies?: string[]
  sort_order: number
  created_at: string
  updated_at: string
}

export interface Education {
  id: string
  user_id: string
  resume_id?: string
  degree: string
  school: string
  location?: string
  graduation_date?: string
  gpa?: string
  description?: string
  honors?: string[]
  relevant_coursework?: string[]
  sort_order: number
  created_at: string
  updated_at: string
}

export interface Skill {
  id: string
  user_id: string
  resume_id?: string
  name: string
  category: string
  proficiency_level: string
  years_experience?: number
  is_featured: boolean
  sort_order: number
  created_at: string
  updated_at: string
}

export interface CoverLetter {
  id: string
  user_id: string
  title: string
  job_title?: string
  company_name?: string
  hiring_manager?: string
  content?: string
  tone: string
  industry: string
  created_at: string
  updated_at: string
}

export interface Portfolio {
  id: string
  user_id: string
  title: string
  subdomain?: string
  theme: string
  layout: string
  color_scheme: string
  sections: any
  is_published: boolean
  custom_domain?: string
  created_at: string
  updated_at: string
}

export interface Project {
  id: string
  user_id: string
  portfolio_id?: string
  title: string
  description?: string
  technologies?: string[]
  live_url?: string
  github_url?: string
  image_url?: string
  featured: boolean
  sort_order: number
  created_at: string
  updated_at: string
}

export interface JobApplication {
  id: string
  user_id: string
  resume_id?: string
  cover_letter_id?: string
  job_title: string
  company_name: string
  job_url?: string
  status: string
  applied_date: string
  notes?: string
  salary_range?: string
  location?: string
  match_score?: number
  created_at: string
  updated_at: string
}

export interface AIFeedback {
  id: string
  user_id: string
  resume_id: string
  overall_score: number
  content_score: number
  skills_score: number
  experience_score: number
  formatting_score: number
  strengths: string[]
  improvements: string[]
  suggestions: string[]
  created_at: string
  updated_at: string
}