import { supabase } from './supabase'
import type { Profile, Resume, Experience, Education, Skill, CoverLetter, Portfolio, Project, JobApplication, AIFeedback } from './supabase'
import toast from 'react-hot-toast'

// Profile operations
export const updateProfile = async (userId: string, updates: Partial<Profile>) => {
  try {
    const { data, error } = await supabase
      .from('profiles')
      .update(updates)
      .eq('user_id', userId)
      .select()
      .single()

    if (error) throw error
    toast.success('Profile updated successfully!')
    return data
  } catch (error: any) {
    toast.error('Failed to update profile')
    throw error
  }
}

// Resume operations
export const createResume = async (userId: string, title: string, templateId: string = 'modern') => {
  try {
    const { data, error } = await supabase
      .from('resumes')
      .insert([
        {
          user_id: userId,
          title,
          template_id: templateId,
          content: {}
        }
      ])
      .select()
      .single()

    if (error) throw error
    toast.success('Resume created successfully!')
    return data
  } catch (error: any) {
    toast.error('Failed to create resume')
    throw error
  }
}

export const getResumes = async (userId: string) => {
  try {
    const { data, error } = await supabase
      .from('resumes')
      .select('*')
      .eq('user_id', userId)
      .order('updated_at', { ascending: false })

    if (error) throw error
    return data
  } catch (error: any) {
    console.error('Error fetching resumes:', error)
    return []
  }
}

export const updateResume = async (resumeId: string, updates: Partial<Resume>) => {
  try {
    const { data, error } = await supabase
      .from('resumes')
      .update(updates)
      .eq('id', resumeId)
      .select()
      .single()

    if (error) throw error
    return data
  } catch (error: any) {
    toast.error('Failed to update resume')
    throw error
  }
}

// Experience operations
export const createExperience = async (userId: string, experience: Partial<Experience>) => {
  try {
    const { data, error } = await supabase
      .from('experiences')
      .insert([{ ...experience, user_id: userId }])
      .select()
      .single()

    if (error) throw error
    return data
  } catch (error: any) {
    toast.error('Failed to add experience')
    throw error
  }
}

export const getExperiences = async (userId: string, resumeId?: string) => {
  try {
    let query = supabase
      .from('experiences')
      .select('*')
      .eq('user_id', userId)

    if (resumeId) {
      query = query.eq('resume_id', resumeId)
    }

    const { data, error } = await query.order('sort_order', { ascending: true })

    if (error) throw error
    return data
  } catch (error: any) {
    console.error('Error fetching experiences:', error)
    return []
  }
}

export const updateExperience = async (experienceId: string, updates: Partial<Experience>) => {
  try {
    const { data, error } = await supabase
      .from('experiences')
      .update(updates)
      .eq('id', experienceId)
      .select()
      .single()

    if (error) throw error
    return data
  } catch (error: any) {
    toast.error('Failed to update experience')
    throw error
  }
}

export const deleteExperience = async (experienceId: string) => {
  try {
    const { error } = await supabase
      .from('experiences')
      .delete()
      .eq('id', experienceId)

    if (error) throw error
    toast.success('Experience deleted successfully!')
  } catch (error: any) {
    toast.error('Failed to delete experience')
    throw error
  }
}

// Education operations
export const createEducation = async (userId: string, education: Partial<Education>) => {
  try {
    const { data, error } = await supabase
      .from('educations')
      .insert([{ ...education, user_id: userId }])
      .select()
      .single()

    if (error) throw error
    return data
  } catch (error: any) {
    toast.error('Failed to add education')
    throw error
  }
}

export const getEducations = async (userId: string, resumeId?: string) => {
  try {
    let query = supabase
      .from('educations')
      .select('*')
      .eq('user_id', userId)

    if (resumeId) {
      query = query.eq('resume_id', resumeId)
    }

    const { data, error } = await query.order('sort_order', { ascending: true })

    if (error) throw error
    return data
  } catch (error: any) {
    console.error('Error fetching educations:', error)
    return []
  }
}

export const updateEducation = async (educationId: string, updates: Partial<Education>) => {
  try {
    const { data, error } = await supabase
      .from('educations')
      .update(updates)
      .eq('id', educationId)
      .select()
      .single()

    if (error) throw error
    return data
  } catch (error: any) {
    toast.error('Failed to update education')
    throw error
  }
}

export const deleteEducation = async (educationId: string) => {
  try {
    const { error } = await supabase
      .from('educations')
      .delete()
      .eq('id', educationId)

    if (error) throw error
    toast.success('Education deleted successfully!')
  } catch (error: any) {
    toast.error('Failed to delete education')
    throw error
  }
}

// Skill operations
export const createSkill = async (userId: string, skill: Partial<Skill>) => {
  try {
    const { data, error } = await supabase
      .from('skills')
      .insert([{ ...skill, user_id: userId }])
      .select()
      .single()

    if (error) throw error
    return data
  } catch (error: any) {
    toast.error('Failed to add skill')
    throw error
  }
}

export const getSkills = async (userId: string, resumeId?: string) => {
  try {
    let query = supabase
      .from('skills')
      .select('*')
      .eq('user_id', userId)

    if (resumeId) {
      query = query.eq('resume_id', resumeId)
    }

    const { data, error } = await query.order('sort_order', { ascending: true })

    if (error) throw error
    return data
  } catch (error: any) {
    console.error('Error fetching skills:', error)
    return []
  }
}

export const updateSkill = async (skillId: string, updates: Partial<Skill>) => {
  try {
    const { data, error } = await supabase
      .from('skills')
      .update(updates)
      .eq('id', skillId)
      .select()
      .single()

    if (error) throw error
    return data
  } catch (error: any) {
    toast.error('Failed to update skill')
    throw error
  }
}

export const deleteSkill = async (skillId: string) => {
  try {
    const { error } = await supabase
      .from('skills')
      .delete()
      .eq('id', skillId)

    if (error) throw error
    toast.success('Skill deleted successfully!')
  } catch (error: any) {
    toast.error('Failed to delete skill')
    throw error
  }
}

// Cover Letter operations
export const createCoverLetter = async (userId: string, coverLetter: Partial<CoverLetter>) => {
  try {
    const { data, error } = await supabase
      .from('cover_letters')
      .insert([{ ...coverLetter, user_id: userId }])
      .select()
      .single()

    if (error) throw error
    toast.success('Cover letter created successfully!')
    return data
  } catch (error: any) {
    toast.error('Failed to create cover letter')
    throw error
  }
}

export const getCoverLetters = async (userId: string) => {
  try {
    const { data, error } = await supabase
      .from('cover_letters')
      .select('*')
      .eq('user_id', userId)
      .order('updated_at', { ascending: false })

    if (error) throw error
    return data
  } catch (error: any) {
    console.error('Error fetching cover letters:', error)
    return []
  }
}

export const updateCoverLetter = async (coverLetterId: string, updates: Partial<CoverLetter>) => {
  try {
    const { data, error } = await supabase
      .from('cover_letters')
      .update(updates)
      .eq('id', coverLetterId)
      .select()
      .single()

    if (error) throw error
    return data
  } catch (error: any) {
    toast.error('Failed to update cover letter')
    throw error
  }
}

// AI Functions
export const generateContent = async (userProfile: any, section: string, jobTitle?: string, company?: string) => {
  try {
    const { data, error } = await supabase.functions.invoke('generate-resume-content', {
      body: { userProfile, section, jobTitle, company }
    })

    if (error) throw error
    return data.content
  } catch (error: any) {
    toast.error('Failed to generate content')
    throw error
  }
}

export const analyzeResume = async (resumeData: any) => {
  try {
    const { data, error } = await supabase.functions.invoke('analyze-resume', {
      body: { resumeData }
    })

    if (error) throw error
    return data
  } catch (error: any) {
    toast.error('Failed to analyze resume')
    throw error
  }
}

export const matchJobs = async (userProfile: any, searchQuery?: string, location?: string, jobType?: string) => {
  try {
    const { data, error } = await supabase.functions.invoke('match-jobs', {
      body: { userProfile, searchQuery, location, jobType }
    })

    if (error) throw error
    return data.jobs
  } catch (error: any) {
    toast.error('Failed to match jobs')
    throw error
  }
}

// Save AI Feedback
export const saveAIFeedback = async (userId: string, resumeId: string, feedback: Partial<AIFeedback>) => {
  try {
    const { data, error } = await supabase
      .from('ai_feedback')
      .insert([{ ...feedback, user_id: userId, resume_id: resumeId }])
      .select()
      .single()

    if (error) throw error
    return data
  } catch (error: any) {
    toast.error('Failed to save AI feedback')
    throw error
  }
}

export const getAIFeedback = async (userId: string, resumeId: string) => {
  try {
    const { data, error } = await supabase
      .from('ai_feedback')
      .select('*')
      .eq('user_id', userId)
      .eq('resume_id', resumeId)
      .order('created_at', { ascending: false })
      .limit(1)
      .single()

    if (error && error.code !== 'PGRST116') throw error
    return data
  } catch (error: any) {
    console.error('Error fetching AI feedback:', error)
    return null
  }
}