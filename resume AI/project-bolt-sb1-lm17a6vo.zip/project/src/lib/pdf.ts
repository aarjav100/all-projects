import jsPDF from 'jspdf'
import html2canvas from 'html2canvas'

export const generatePDF = async (elementId: string, filename: string = 'resume.pdf') => {
  try {
    const element = document.getElementById(elementId)
    if (!element) {
      throw new Error('Element not found')
    }

    // Create canvas from HTML element
    const canvas = await html2canvas(element, {
      scale: 2,
      useCORS: true,
      allowTaint: true,
      backgroundColor: '#ffffff'
    })

    // Calculate dimensions
    const imgWidth = 210 // A4 width in mm
    const pageHeight = 295 // A4 height in mm
    const imgHeight = (canvas.height * imgWidth) / canvas.width
    let heightLeft = imgHeight

    // Create PDF
    const pdf = new jsPDF('p', 'mm', 'a4')
    let position = 0

    // Add first page
    pdf.addImage(canvas.toDataURL('image/png'), 'PNG', 0, position, imgWidth, imgHeight)
    heightLeft -= pageHeight

    // Add additional pages if needed
    while (heightLeft >= 0) {
      position = heightLeft - imgHeight
      pdf.addPage()
      pdf.addImage(canvas.toDataURL('image/png'), 'PNG', 0, position, imgWidth, imgHeight)
      heightLeft -= pageHeight
    }

    // Save PDF
    pdf.save(filename)
    return true
  } catch (error) {
    console.error('Error generating PDF:', error)
    throw error
  }
}

export const generateResumeHTML = (userProfile: any, template: string = 'modern') => {
  const formatDate = (dateString: string) => {
    if (!dateString) return ''
    const date = new Date(dateString)
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short' })
  }

  return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8">
      <title>${userProfile.full_name || 'Resume'}</title>
      <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 20px; line-height: 1.6; }
        .header { border-bottom: 2px solid #3B82F6; padding-bottom: 20px; margin-bottom: 20px; }
        .name { font-size: 28px; font-weight: bold; color: #1F2937; margin-bottom: 8px; }
        .title { font-size: 18px; color: #3B82F6; font-weight: 600; margin-bottom: 16px; }
        .contact { font-size: 14px; color: #6B7280; }
        .section { margin-bottom: 24px; }
        .section-title { font-size: 16px; font-weight: bold; color: #1F2937; border-bottom: 1px solid #E5E7EB; padding-bottom: 4px; margin-bottom: 12px; }
        .experience-item, .education-item { margin-bottom: 16px; }
        .job-title { font-weight: 600; color: #1F2937; }
        .company { color: #3B82F6; font-weight: 500; }
        .date-location { font-size: 14px; color: #6B7280; }
        .description { margin-top: 8px; white-space: pre-line; }
        .skills-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 16px; }
        .skill-category { margin-bottom: 12px; }
        .skill-category-title { font-weight: 600; color: #1F2937; margin-bottom: 8px; }
        .skill-item { display: flex; justify-content: space-between; margin-bottom: 4px; }
      </style>
    </head>
    <body>
      <div class="header">
        <div class="name">${userProfile.full_name || 'Your Name'}</div>
        <div class="title">${userProfile.professional_title || 'Professional Title'}</div>
        <div class="contact">
          ${userProfile.email ? `${userProfile.email} • ` : ''}
          ${userProfile.phone ? `${userProfile.phone} • ` : ''}
          ${userProfile.location || ''}
        </div>
      </div>

      ${userProfile.summary ? `
        <div class="section">
          <div class="section-title">Professional Summary</div>
          <div>${userProfile.summary}</div>
        </div>
      ` : ''}

      ${userProfile.experiences && userProfile.experiences.length > 0 ? `
        <div class="section">
          <div class="section-title">Professional Experience</div>
          ${userProfile.experiences.map((exp: any) => `
            <div class="experience-item">
              <div style="display: flex; justify-content: space-between; align-items: start;">
                <div>
                  <div class="job-title">${exp.title}</div>
                  <div class="company">${exp.company}</div>
                </div>
                <div class="date-location" style="text-align: right;">
                  <div>${formatDate(exp.start_date)} - ${exp.is_current ? 'Present' : formatDate(exp.end_date)}</div>
                  <div>${exp.location || ''}</div>
                </div>
              </div>
              ${exp.description ? `<div class="description">${exp.description}</div>` : ''}
            </div>
          `).join('')}
        </div>
      ` : ''}

      ${userProfile.educations && userProfile.educations.length > 0 ? `
        <div class="section">
          <div class="section-title">Education</div>
          ${userProfile.educations.map((edu: any) => `
            <div class="education-item">
              <div style="display: flex; justify-content: space-between; align-items: start;">
                <div>
                  <div class="job-title">${edu.degree}</div>
                  <div class="company">${edu.school}</div>
                  ${edu.gpa ? `<div style="font-size: 14px; color: #6B7280;">GPA: ${edu.gpa}</div>` : ''}
                </div>
                <div class="date-location" style="text-align: right;">
                  <div>${formatDate(edu.graduation_date)}</div>
                  <div>${edu.location || ''}</div>
                </div>
              </div>
            </div>
          `).join('')}
        </div>
      ` : ''}

      ${userProfile.skills && userProfile.skills.length > 0 ? `
        <div class="section">
          <div class="section-title">Skills</div>
          <div class="skills-grid">
            ${['Technical', 'Languages', 'Soft Skills', 'Tools'].map(category => {
              const categorySkills = userProfile.skills.filter((skill: any) => skill.category === category)
              if (categorySkills.length === 0) return ''
              
              return `
                <div class="skill-category">
                  <div class="skill-category-title">${category}</div>
                  ${categorySkills.map((skill: any) => `
                    <div class="skill-item">
                      <span>${skill.name}</span>
                      <span style="font-size: 12px; color: #6B7280;">${skill.proficiency_level}</span>
                    </div>
                  `).join('')}
                </div>
              `
            }).join('')}
          </div>
        </div>
      ` : ''}
    </body>
    </html>
  `
}