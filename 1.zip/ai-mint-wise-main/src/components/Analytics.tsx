import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from 'recharts';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';

interface ExpenseData {
  category: string;
  amount: number;
  color: string;
}

interface MonthlyData {
  month: string;
  amount: number;
}

interface DailyData {
  date: string;
  amount: number;
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8', '#82CA9D', '#FFC658', '#FF7C7C'];

export function Analytics() {
  const [timeRange, setTimeRange] = useState('month');
  const [expensesByCategory, setExpensesByCategory] = useState<ExpenseData[]>([]);
  const [monthlyExpenses, setMonthlyExpenses] = useState<MonthlyData[]>([]);
  const [dailyExpenses, setDailyExpenses] = useState<DailyData[]>([]);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();

  useEffect(() => {
    if (user) {
      loadAnalyticsData();
    }
  }, [user, timeRange]);

  const loadAnalyticsData = async () => {
    setLoading(true);
    try {
      await Promise.all([
        loadExpensesByCategory(),
        loadMonthlyExpenses(),
        loadDailyExpenses()
      ]);
    } catch (error) {
      console.error('Error loading analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadExpensesByCategory = async () => {
    try {
      const startDate = getStartDate(timeRange);
      
      const { data, error } = await supabase
        .from('expenses')
        .select(`
          amount,
          expense_categories (
            name,
            color
          )
        `)
        .eq('user_id', user?.id)
        .gte('expense_date', startDate.toISOString().split('T')[0]);

      if (error) throw error;

      const categoryTotals = (data || []).reduce((acc: Record<string, { amount: number; color: string }>, expense) => {
        const category = expense.expense_categories?.name || 'Other';
        const color = expense.expense_categories?.color || '#6B7280';
        
        if (!acc[category]) {
          acc[category] = { amount: 0, color };
        }
        acc[category].amount += Number(expense.amount);
        return acc;
      }, {});

      const categoryData = Object.entries(categoryTotals).map(([category, data]) => ({
        category,
        amount: data.amount,
        color: data.color
      }));

      setExpensesByCategory(categoryData);
    } catch (error) {
      console.error('Error loading expenses by category:', error);
    }
  };

  const loadMonthlyExpenses = async () => {
    try {
      const { data, error } = await supabase
        .from('expenses')
        .select('amount, expense_date')
        .eq('user_id', user?.id)
        .gte('expense_date', new Date(Date.now() - 365 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]);

      if (error) throw error;

      const monthlyTotals = (data || []).reduce((acc: Record<string, number>, expense) => {
        const month = new Date(expense.expense_date).toISOString().slice(0, 7); // YYYY-MM
        if (!acc[month]) acc[month] = 0;
        acc[month] += Number(expense.amount);
        return acc;
      }, {});

      const monthlyData = Object.entries(monthlyTotals)
        .map(([month, amount]) => ({
          month: new Date(month + '-01').toLocaleDateString('en-US', { month: 'short', year: 'numeric' }),
          amount
        }))
        .sort((a, b) => new Date(a.month + ' 1, 2000').getTime() - new Date(b.month + ' 1, 2000').getTime());

      setMonthlyExpenses(monthlyData);
    } catch (error) {
      console.error('Error loading monthly expenses:', error);
    }
  };

  const loadDailyExpenses = async () => {
    try {
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - 30); // Last 30 days
      
      const { data, error } = await supabase
        .from('expenses')
        .select('amount, expense_date')
        .eq('user_id', user?.id)
        .gte('expense_date', startDate.toISOString().split('T')[0]);

      if (error) throw error;

      const dailyTotals = (data || []).reduce((acc: Record<string, number>, expense) => {
        const date = expense.expense_date;
        if (!acc[date]) acc[date] = 0;
        acc[date] += Number(expense.amount);
        return acc;
      }, {});

      const dailyData = Object.entries(dailyTotals)
        .map(([date, amount]) => ({
          date: new Date(date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
          amount
        }))
        .sort((a, b) => new Date(a.date + ', 2000').getTime() - new Date(b.date + ', 2000').getTime());

      setDailyExpenses(dailyData);
    } catch (error) {
      console.error('Error loading daily expenses:', error);
    }
  };

  const getStartDate = (range: string): Date => {
    const date = new Date();
    switch (range) {
      case 'week':
        date.setDate(date.getDate() - 7);
        break;
      case 'month':
        date.setMonth(date.getMonth() - 1);
        break;
      case 'quarter':
        date.setMonth(date.getMonth() - 3);
        break;
      case 'year':
        date.setFullYear(date.getFullYear() - 1);
        break;
      default:
        date.setMonth(date.getMonth() - 1);
    }
    return date;
  };

  const getTotalExpenses = () => {
    return expensesByCategory.reduce((sum, item) => sum + item.amount, 0);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Analytics</h2>
          <p className="text-muted-foreground">Visualize your spending patterns</p>
        </div>
        
        <Select value={timeRange} onValueChange={setTimeRange}>
          <SelectTrigger className="w-40">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="week">Last Week</SelectItem>
            <SelectItem value="month">Last Month</SelectItem>
            <SelectItem value="quarter">Last 3 Months</SelectItem>
            <SelectItem value="year">Last Year</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Expenses</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${getTotalExpenses().toFixed(2)}</div>
            <p className="text-xs text-muted-foreground capitalize">
              for the selected {timeRange === 'quarter' ? '3 months' : `${timeRange}`}
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Categories</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{expensesByCategory.length}</div>
            <p className="text-xs text-muted-foreground">
              categories with expenses
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Average Daily</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              ${dailyExpenses.length > 0 
                ? (dailyExpenses.reduce((sum, day) => sum + day.amount, 0) / dailyExpenses.length).toFixed(2)
                : '0.00'
              }
            </div>
            <p className="text-xs text-muted-foreground">
              over last 30 days
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Expenses by Category - Pie Chart */}
        <Card>
          <CardHeader>
            <CardTitle>Expenses by Category</CardTitle>
            <CardDescription>
              Breakdown of spending by category
            </CardDescription>
          </CardHeader>
          <CardContent>
            {expensesByCategory.length > 0 ? (
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={expensesByCategory}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ category, amount, percent }) => 
                        `${category}: $${amount.toFixed(0)} (${(percent * 100).toFixed(0)}%)`
                      }
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="amount"
                    >
                      {expensesByCategory.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color || COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value: number) => [`$${value.toFixed(2)}`, 'Amount']} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="h-80 flex items-center justify-center text-muted-foreground">
                No expense data available for the selected period
              </div>
            )}
          </CardContent>
        </Card>

        {/* Expenses by Category - Bar Chart */}
        <Card>
          <CardHeader>
            <CardTitle>Category Breakdown</CardTitle>
            <CardDescription>
              Spending amounts by category
            </CardDescription>
          </CardHeader>
          <CardContent>
            {expensesByCategory.length > 0 ? (
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={expensesByCategory}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis 
                      dataKey="category" 
                      angle={-45}
                      textAnchor="end"
                      height={80}
                      fontSize={12}
                    />
                    <YAxis />
                    <Tooltip formatter={(value: number) => [`$${value.toFixed(2)}`, 'Amount']} />
                    <Bar dataKey="amount" fill="#8884d8">
                      {expensesByCategory.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color || COLORS[index % COLORS.length]} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="h-80 flex items-center justify-center text-muted-foreground">
                No expense data available for the selected period
              </div>
            )}
          </CardContent>
        </Card>

        {/* Monthly Trend */}
        <Card>
          <CardHeader>
            <CardTitle>Monthly Trends</CardTitle>
            <CardDescription>
              Spending trends over the last 12 months
            </CardDescription>
          </CardHeader>
          <CardContent>
            {monthlyExpenses.length > 0 ? (
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={monthlyExpenses}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip formatter={(value: number) => [`$${value.toFixed(2)}`, 'Amount']} />
                    <Line type="monotone" dataKey="amount" stroke="#8884d8" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="h-80 flex items-center justify-center text-muted-foreground">
                No monthly data available
              </div>
            )}
          </CardContent>
        </Card>

        {/* Daily Spending (Last 30 Days) */}
        <Card>
          <CardHeader>
            <CardTitle>Daily Spending</CardTitle>
            <CardDescription>
              Daily expenses over the last 30 days
            </CardDescription>
          </CardHeader>
          <CardContent>
            {dailyExpenses.length > 0 ? (
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={dailyExpenses}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis 
                      dataKey="date" 
                      angle={-45}
                      textAnchor="end"
                      height={80}
                      fontSize={10}
                    />
                    <YAxis />
                    <Tooltip formatter={(value: number) => [`$${value.toFixed(2)}`, 'Amount']} />
                    <Bar dataKey="amount" fill="#82ca9d" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="h-80 flex items-center justify-center text-muted-foreground">
                No daily data available
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}