# Security Guide for searchKaro

## Overview
This document outlines the security measures implemented in searchKaro and best practices for maintaining application security.

## Critical Security Fixes Implemented

### 1. Profile Data Protection
**Issue:** User profiles were publicly readable, exposing sensitive data (phone numbers, dates of birth, full names).

**Fix:** 
- Implemented granular RLS policies that restrict profile visibility
- Users can only view their own full profile data
- Other users can only access limited public profile information
- Created secure `get_public_profile()` function for safe data access

**Usage:**
```typescript
import { getPublicProfile, getOwnProfile } from '@/lib/profile-utils';

// Get public profile (safe for displaying to other users)
const { data } = await getPublicProfile(userId);

// Get own full profile (includes sensitive data)
const { data } = await getOwnProfile(currentUserId);
```

### 2. Role Assignment Security
**Issue:** Users could grant themselves any role, including 'host', leading to privilege escalation.

**Fix:**
- Removed ability for users to self-assign the 'host' role
- Users can only self-assign the 'guest' role
- Host role must be assigned via secure `add_host_role()` function
- Function uses SECURITY DEFINER to control access

**Usage:**
```typescript
// Safe - users can add guest role
await auth.addRole('guest');

// Secure - host role via controlled function
await auth.addRole('host'); // Uses add_host_role() internally
```

### 3. Payment Data Protection
**Issue:** Payment intent IDs were visible to property hosts.

**Fix:**
- Added comments marking sensitive fields
- Maintained RLS policies ensuring only booking participants see data
- Separated payment viewing from booking management

### 4. Input Validation
**Issue:** No validation on user inputs, risking injection attacks.

**Fix:**
- Implemented comprehensive validation schemas using Zod
- All user inputs validated before processing
- Client-side and server-side validation enforced

**Usage:**
```typescript
import { loginSchema, propertySchema } from '@/lib/validation-schemas';

// Validate before submission
const result = loginSchema.safeParse(formData);
if (!result.success) {
  // Handle validation errors
  console.error(result.error.issues);
}
```

## Authentication Security

### Secure Authentication Hook
Use `useSecureAuth` hook instead of direct `useAuth` for enhanced security:

```typescript
import { useSecureAuth } from '@/hooks/useSecureAuth';

function LoginForm() {
  const { secureSignIn } = useSecureAuth();
  
  const handleLogin = async (email: string, password: string) => {
    const { success, error } = await secureSignIn(email, password);
    // Input validation and secure error handling included
  };
}
```

### Password Requirements
- Minimum 8 characters
- At least one uppercase letter
- At least one lowercase letter
- At least one number

### Authentication Best Practices
1. Never log authentication errors to console in production
2. Use generic error messages to prevent user enumeration
3. Always validate inputs before authentication
4. Enable email verification for new accounts
5. Implement rate limiting on login attempts

## Database Security (RLS Policies)

### User Roles Table
```sql
-- Users can only view their own roles
-- Users can only add 'guest' role to themselves
-- 'host' role requires admin approval via add_host_role()
```

### Profiles Table
```sql
-- Users see their own full profile
-- Others see limited public profile only (first_name, avatar, verification status)
```

### Properties Table
```sql
-- Anyone can view active properties
-- Only hosts can manage their own properties
-- Host role required to create properties
```

### Bookings Table
```sql
-- Guests view their own bookings
-- Hosts view bookings for their properties
-- Payment details restricted
```

## API Security

### Secure Functions
All database functions use `SECURITY DEFINER` to prevent RLS recursion:

```sql
CREATE FUNCTION public.has_role(_user_id uuid, _role app_role)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
```

### Rate Limiting
Implement rate limiting on Edge Functions to prevent abuse:

```typescript
// Example rate limit implementation
const RATE_LIMIT = 100; // requests per minute
const WINDOW = 60000; // 1 minute in ms
```

## Validation Schemas

### Available Schemas
- `loginSchema` - Email and password validation
- `registerSchema` - Full registration with password strength
- `profileUpdateSchema` - Profile modification validation
- `propertySchema` - Property listing validation
- `bookingSchema` - Booking request validation
- `messageSchema` - Message content validation
- `reviewSchema` - Review submission validation
- `searchSchema` - Search query validation

### Using Schemas
```typescript
import { propertySchema } from '@/lib/validation-schemas';

try {
  const validated = propertySchema.parse(propertyData);
  // Data is safe to use
} catch (error) {
  if (error instanceof z.ZodError) {
    // Handle validation errors
    error.issues.forEach(issue => {
      console.error(issue.message);
    });
  }
}
```

## PWA Security

### Service Worker
- Caches only safe, non-sensitive content
- Skips caching for Supabase API calls
- Always fetches authentication data fresh

### Content Security
- Proper HTTPS enforcement
- Secure headers configured in index.html
- No inline scripts allowed

## Security Checklist

### Before Deployment
- [ ] Enable leaked password protection in Supabase Auth settings
- [ ] Review all RLS policies
- [ ] Verify role assignment is secure
- [ ] Test input validation on all forms
- [ ] Ensure sensitive data is not logged
- [ ] Check that service worker doesn't cache sensitive data
- [ ] Verify HTTPS is enforced
- [ ] Test authentication flows
- [ ] Review error messages (no information leakage)
- [ ] Enable rate limiting on critical endpoints

### Regular Security Maintenance
- [ ] Update dependencies monthly
- [ ] Review Supabase logs for suspicious activity
- [ ] Monitor authentication failures
- [ ] Audit RLS policies quarterly
- [ ] Test for common vulnerabilities (OWASP Top 10)
- [ ] Review and rotate API keys
- [ ] Check for exposed secrets in code
- [ ] Validate all third-party integrations

## Reporting Security Issues

If you discover a security vulnerability, please email security@searchkaro.com with:
- Description of the vulnerability
- Steps to reproduce
- Potential impact
- Suggested fix (if any)

Do not publicly disclose security issues until they have been addressed.

## Additional Resources

- [Supabase Security Documentation](https://supabase.com/docs/guides/auth/row-level-security)
- [OWASP Top 10](https://owasp.org/www-project-top-ten/)
- [Web Security Best Practices](https://developer.mozilla.org/en-US/docs/Web/Security)
- [Zod Documentation](https://zod.dev/)

## Version History

### Phase 8 Security Updates (Current)
- Implemented profile data protection
- Secured role assignment
- Added comprehensive input validation
- Created secure authentication hooks
- Enhanced payment data protection
- Documented all security measures
