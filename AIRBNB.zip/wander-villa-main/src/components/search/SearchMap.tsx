import { useEffect, useRef, useState } from "react";
import mapboxgl from "mapbox-gl";
import "mapbox-gl/dist/mapbox-gl.css";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Info, Heart, Star } from "lucide-react";
import { Link } from "react-router-dom";

interface Property {
  id: number;
  title: string;
  location: string;
  price: number;
  rating: number;
  reviews: number;
  image: string;
  lat: number;
  lng: number;
}

interface SearchMapProps {
  properties: Property[];
  favorites: number[];
  onToggleFavorite: (id: number) => void;
}

const SearchMap = ({ properties, favorites, onToggleFavorite }: SearchMapProps) => {
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<mapboxgl.Map | null>(null);
  const [selectedProperty, setSelectedProperty] = useState<Property | null>(null);
  const [mapboxToken, setMapboxToken] = useState("");
  const [showTokenInput, setShowTokenInput] = useState(true);

  useEffect(() => {
    if (!mapContainer.current || !mapboxToken) return;

    mapboxgl.accessToken = mapboxToken;

    try {
      map.current = new mapboxgl.Map({
        container: mapContainer.current,
        style: "mapbox://styles/mapbox/streets-v12",
        center: [-98.5795, 39.8283], // Center of USA
        zoom: 3,
      });

      map.current.addControl(new mapboxgl.NavigationControl(), "top-right");

      // Add markers for properties
      properties.forEach((property) => {
        const el = document.createElement("div");
        el.className = "property-marker";
        el.innerHTML = `
          <div class="bg-primary text-primary-foreground px-3 py-1.5 rounded-full font-semibold text-sm shadow-lg cursor-pointer hover:scale-110 transition-transform">
            $${property.price}
          </div>
        `;

        el.addEventListener("click", () => {
          setSelectedProperty(property);
          map.current?.flyTo({
            center: [property.lng, property.lat],
            zoom: 12,
          });
        });

        new mapboxgl.Marker(el)
          .setLngLat([property.lng, property.lat])
          .addTo(map.current!);
      });

      setShowTokenInput(false);
    } catch (error) {
      console.error("Error initializing map:", error);
      setShowTokenInput(true);
    }

    return () => {
      map.current?.remove();
    };
  }, [properties, mapboxToken]);

  const handleTokenSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (mapboxToken.trim()) {
      setShowTokenInput(false);
    }
  };

  if (showTokenInput) {
    return (
      <Card className="p-8 max-w-2xl mx-auto">
        <div className="space-y-4">
          <div className="flex items-start gap-3">
            <Info className="w-5 h-5 text-primary mt-0.5" />
            <div className="space-y-2 flex-1">
              <h3 className="font-semibold text-lg">Mapbox Token Required</h3>
              <p className="text-sm text-muted-foreground">
                To view the interactive map, please enter your Mapbox public token. 
                You can get one for free at{" "}
                <a
                  href="https://mapbox.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-primary hover:underline"
                >
                  mapbox.com
                </a>
              </p>
              <form onSubmit={handleTokenSubmit} className="flex gap-2 pt-2">
                <Input
                  placeholder="pk.eyJ1..."
                  value={mapboxToken}
                  onChange={(e) => setMapboxToken(e.target.value)}
                  className="flex-1"
                />
                <Button type="submit">Load Map</Button>
              </form>
            </div>
          </div>
        </div>
      </Card>
    );
  }

  return (
    <div className="relative h-[calc(100vh-16rem)] rounded-lg overflow-hidden">
      <div ref={mapContainer} className="absolute inset-0" />

      {/* Selected Property Card */}
      {selectedProperty && (
        <Card className="absolute bottom-4 left-1/2 -translate-x-1/2 w-full max-w-sm z-10 overflow-hidden">
          <Link to={`/property/${selectedProperty.id}`}>
            <div className="aspect-video relative">
              <img
                src={selectedProperty.image}
                alt={selectedProperty.title}
                className="w-full h-full object-cover"
              />
              <button
                onClick={(e) => {
                  e.preventDefault();
                  onToggleFavorite(selectedProperty.id);
                }}
                className="absolute top-3 right-3 bg-white/90 backdrop-blur-sm rounded-full p-2 hover:bg-white transition-colors"
              >
                <Heart
                  className={`w-5 h-5 ${
                    favorites.includes(selectedProperty.id)
                      ? "fill-primary text-primary"
                      : "text-foreground"
                  }`}
                />
              </button>
            </div>
          </Link>

          <div className="p-4 space-y-2">
            <div className="flex items-start justify-between gap-2">
              <div className="flex-1 min-w-0">
                <Link to={`/property/${selectedProperty.id}`}>
                  <h3 className="font-semibold text-base hover:text-primary transition-colors">
                    {selectedProperty.title}
                  </h3>
                </Link>
                <p className="text-sm text-muted-foreground">
                  {selectedProperty.location}
                </p>
              </div>
              <div className="flex items-center gap-1 text-sm shrink-0">
                <Star className="w-4 h-4 fill-warning text-warning" />
                <span className="font-medium">{selectedProperty.rating}</span>
              </div>
            </div>

            <div className="flex items-baseline gap-1">
              <span className="text-xl font-bold text-primary">
                ${selectedProperty.price}
              </span>
              <span className="text-sm text-muted-foreground">/ night</span>
            </div>

            <Button asChild className="w-full" size="sm">
              <Link to={`/property/${selectedProperty.id}`}>View Details</Link>
            </Button>
          </div>
        </Card>
      )}
    </div>
  );
};

export default SearchMap;
