import { useState } from "react";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetFooter,
} from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Wifi, Car, Droplet, Tv, Wind, Utensils, PawPrint, Cigarette } from "lucide-react";

interface SearchFiltersProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onFiltersChange: (count: number) => void;
}

const SearchFilters = ({ open, onOpenChange, onFiltersChange }: SearchFiltersProps) => {
  const [priceRange, setPriceRange] = useState([50, 500]);
  const [propertyTypes, setPropertyTypes] = useState<string[]>([]);
  const [amenities, setAmenities] = useState<string[]>([]);
  const [instantBook, setInstantBook] = useState(false);
  const [petFriendly, setPetFriendly] = useState(false);
  const [smokingAllowed, setSmokingAllowed] = useState(false);

  const propertyTypeOptions = [
    { id: "entire", label: "Entire place" },
    { id: "private", label: "Private room" },
    { id: "shared", label: "Shared room" },
  ];

  const amenityOptions = [
    { id: "wifi", label: "WiFi", icon: Wifi },
    { id: "parking", label: "Parking", icon: Car },
    { id: "pool", label: "Pool", icon: Droplet },
    { id: "tv", label: "TV", icon: Tv },
    { id: "ac", label: "Air Conditioning", icon: Wind },
    { id: "kitchen", label: "Kitchen", icon: Utensils },
  ];

  const handlePropertyTypeToggle = (type: string) => {
    setPropertyTypes(prev =>
      prev.includes(type) ? prev.filter(t => t !== type) : [...prev, type]
    );
  };

  const handleAmenityToggle = (amenity: string) => {
    setAmenities(prev =>
      prev.includes(amenity) ? prev.filter(a => a !== amenity) : [...prev, amenity]
    );
  };

  const handleClearAll = () => {
    setPriceRange([50, 500]);
    setPropertyTypes([]);
    setAmenities([]);
    setInstantBook(false);
    setPetFriendly(false);
    setSmokingAllowed(false);
    onFiltersChange(0);
  };

  const handleApply = () => {
    const count = 
      propertyTypes.length +
      amenities.length +
      (instantBook ? 1 : 0) +
      (petFriendly ? 1 : 0) +
      (smokingAllowed ? 1 : 0) +
      (priceRange[0] !== 50 || priceRange[1] !== 500 ? 1 : 0);
    
    onFiltersChange(count);
    onOpenChange(false);
  };

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="bottom" className="h-[90vh] overflow-y-auto">
        <SheetHeader>
          <SheetTitle>Filters</SheetTitle>
          <SheetDescription>
            Refine your search to find the perfect property
          </SheetDescription>
        </SheetHeader>

        <div className="space-y-6 py-6">
          {/* Price Range */}
          <div className="space-y-4">
            <Label className="text-base font-semibold">Price Range</Label>
            <div className="space-y-4">
              <Slider
                min={0}
                max={1000}
                step={10}
                value={priceRange}
                onValueChange={setPriceRange}
                className="py-4"
              />
              <div className="flex items-center justify-between text-sm">
                <div className="space-y-1">
                  <p className="text-muted-foreground">Minimum</p>
                  <p className="font-semibold">${priceRange[0]}</p>
                </div>
                <div className="space-y-1 text-right">
                  <p className="text-muted-foreground">Maximum</p>
                  <p className="font-semibold">${priceRange[1]}</p>
                </div>
              </div>
            </div>
          </div>

          <Separator />

          {/* Property Type */}
          <div className="space-y-4">
            <Label className="text-base font-semibold">Property Type</Label>
            <div className="space-y-3">
              {propertyTypeOptions.map((option) => (
                <div key={option.id} className="flex items-center space-x-2">
                  <Checkbox
                    id={option.id}
                    checked={propertyTypes.includes(option.id)}
                    onCheckedChange={() => handlePropertyTypeToggle(option.id)}
                  />
                  <label
                    htmlFor={option.id}
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                  >
                    {option.label}
                  </label>
                </div>
              ))}
            </div>
          </div>

          <Separator />

          {/* Amenities */}
          <div className="space-y-4">
            <Label className="text-base font-semibold">Amenities</Label>
            <div className="grid grid-cols-2 gap-3">
              {amenityOptions.map((option) => {
                const Icon = option.icon;
                return (
                  <div
                    key={option.id}
                    onClick={() => handleAmenityToggle(option.id)}
                    className={`flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-colors ${
                      amenities.includes(option.id)
                        ? "border-primary bg-primary/5"
                        : "border-border hover:border-primary/50"
                    }`}
                  >
                    <Icon className="w-5 h-5 text-muted-foreground" />
                    <span className="text-sm font-medium">{option.label}</span>
                  </div>
                );
              })}
            </div>
          </div>

          <Separator />

          {/* House Rules */}
          <div className="space-y-4">
            <Label className="text-base font-semibold">House Rules</Label>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <PawPrint className="w-4 h-4 text-muted-foreground" />
                  <label htmlFor="pet-friendly" className="text-sm font-medium">
                    Pet Friendly
                  </label>
                </div>
                <Switch
                  id="pet-friendly"
                  checked={petFriendly}
                  onCheckedChange={setPetFriendly}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Cigarette className="w-4 h-4 text-muted-foreground" />
                  <label htmlFor="smoking" className="text-sm font-medium">
                    Smoking Allowed
                  </label>
                </div>
                <Switch
                  id="smoking"
                  checked={smokingAllowed}
                  onCheckedChange={setSmokingAllowed}
                />
              </div>
            </div>
          </div>

          <Separator />

          {/* Booking Options */}
          <div className="space-y-4">
            <Label className="text-base font-semibold">Booking Options</Label>
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <label htmlFor="instant-book" className="text-sm font-medium">
                  Instant Book
                </label>
                <p className="text-xs text-muted-foreground">
                  Book without waiting for host approval
                </p>
              </div>
              <Switch
                id="instant-book"
                checked={instantBook}
                onCheckedChange={setInstantBook}
              />
            </div>
          </div>
        </div>

        <SheetFooter className="gap-2 sm:gap-0">
          <Button variant="outline" onClick={handleClearAll} className="flex-1">
            Clear All
          </Button>
          <Button onClick={handleApply} className="flex-1">
            Apply Filters
          </Button>
        </SheetFooter>
      </SheetContent>
    </Sheet>
  );
};

export default SearchFilters;
