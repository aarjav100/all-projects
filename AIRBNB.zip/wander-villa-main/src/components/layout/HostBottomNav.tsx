import { Home, Calendar, MessageSquare, MoreHorizontal, LayoutDashboard } from "lucide-react";
import { Link, useLocation } from "react-router-dom";

export const HostBottomNav = () => {
  const location = useLocation();
  
  const isActive = (path: string) => location.pathname === path;
  
  const navItems = [
    { icon: LayoutDashboard, label: "Dashboard", path: "/host/dashboard" },
    { icon: Home, label: "Properties", path: "/host/properties" },
    { icon: Calendar, label: "Calendar", path: "/host/calendar" },
    { icon: MessageSquare, label: "Messages", path: "/messages" },
    { icon: MoreHorizontal, label: "More", path: "/settings" },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-background border-t border-border z-50">
      <div className="flex justify-around items-center h-16">
        {navItems.map((item) => {
          const Icon = item.icon;
          const active = isActive(item.path);
          return (
            <Link
              key={item.path}
              to={item.path}
              className={`flex flex-col items-center justify-center flex-1 h-full transition-colors ${
                active ? "text-primary" : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <Icon className="h-5 w-5 mb-1" />
              <span className="text-xs">{item.label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
};
