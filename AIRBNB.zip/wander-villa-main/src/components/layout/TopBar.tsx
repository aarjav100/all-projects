import { Menu, Bell } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Link, useLocation } from "react-router-dom";

const TopBar = () => {
  const location = useLocation();
  const isHostMode = location.pathname.startsWith("/host");
  
  return (
    <header className="fixed top-0 left-0 right-0 z-40 bg-card border-b border-border">
      <div className="flex items-center justify-between h-16 max-w-screen-xl mx-auto px-4">
        <div className="flex items-center gap-3">
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon">
                <Menu className="w-5 h-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-80">
              <nav className="flex flex-col gap-4 mt-8">
                <Link to="/messages" className="text-base font-medium hover:text-primary transition-colors">
                  Messages
                </Link>
                <Link to="/help" className="text-base font-medium hover:text-primary transition-colors">
                  Help & Support
                </Link>
                <Link to="/settings" className="text-base font-medium hover:text-primary transition-colors">
                  Settings
                </Link>
                {isHostMode ? (
                  <Link to="/" className="text-base font-medium hover:text-primary transition-colors">
                    Switch to Guest Mode
                  </Link>
                ) : (
                  <Link to="/host/dashboard" className="text-base font-medium hover:text-primary transition-colors">
                    Become a Host
                  </Link>
                )}
                <div className="border-t border-border pt-4 mt-4">
                  <button className="text-base font-medium text-destructive hover:text-destructive/90 transition-colors">
                    Log Out
                  </button>
                </div>
              </nav>
            </SheetContent>
          </Sheet>
          
          <Link to="/" className="flex items-center gap-2">
            <span className="text-2xl font-bold text-primary">searchKaro</span>
          </Link>
        </div>

        <Button variant="ghost" size="icon">
          <Bell className="w-5 h-5" />
        </Button>
      </div>
    </header>
  );
};

export default TopBar;
