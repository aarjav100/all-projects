import { ReactNode } from "react";
import { useLocation } from "react-router-dom";
import TopBar from "./TopBar";
import BottomNav from "./BottomNav";
import { HostBottomNav } from "./HostBottomNav";

interface LayoutProps {
  children: ReactNode;
  showNav?: boolean;
}

const Layout = ({ children, showNav = true }: LayoutProps) => {
  const location = useLocation();
  const isHostMode = location.pathname.startsWith("/host");

  return (
    <div className="min-h-screen bg-background">
      {showNav && <TopBar />}
      <main className={showNav ? "pt-16 pb-16" : ""}>
        {children}
      </main>
      {showNav && (isHostMode ? <HostBottomNav /> : <BottomNav />)}
    </div>
  );
};

export default Layout;
