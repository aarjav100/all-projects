import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { loginSchema, registerSchema } from '@/lib/validation-schemas';
import { z } from 'zod';

/**
 * Secure authentication hook with input validation
 * Prevents common authentication vulnerabilities
 */
export function useSecureAuth() {
  const auth = useAuth();
  const { toast } = useToast();

  const secureSignIn = async (email: string, password: string) => {
    try {
      // Validate inputs before sending to auth service
      const validatedData = loginSchema.parse({ email, password });
      
      const { error } = await auth.signIn(validatedData.email, validatedData.password);
      
      if (error) {
        // Don't reveal specific error details for security
        toast({
          title: 'Login Failed',
          description: 'Invalid email or password. Please try again.',
          variant: 'destructive'
        });
        return { success: false, error };
      }

      return { success: true, error: null };
    } catch (error) {
      if (error instanceof z.ZodError) {
        toast({
          title: 'Validation Error',
          description: error.issues[0].message,
          variant: 'destructive'
        });
      }
      return { success: false, error };
    }
  };

  const secureSignUp = async (
    email: string, 
    password: string, 
    firstName: string, 
    lastName: string,
    phone?: string
  ) => {
    try {
      // Validate all inputs
      const validatedData = registerSchema.parse({ 
        email, 
        password, 
        firstName, 
        lastName,
        phone 
      });
      
      const { error } = await auth.signUp(
        validatedData.email, 
        validatedData.password,
        {
          first_name: validatedData.firstName,
          last_name: validatedData.lastName,
          phone: validatedData.phone
        }
      );
      
      if (error) {
        // Provide helpful but secure error messages
        let description = 'Registration failed. Please try again.';
        if (error.message.includes('already registered')) {
          description = 'An account with this email already exists.';
        }
        
        toast({
          title: 'Registration Failed',
          description,
          variant: 'destructive'
        });
        return { success: false, error };
      }

      toast({
        title: 'Account Created',
        description: 'Please check your email to verify your account.',
      });

      return { success: true, error: null };
    } catch (error) {
      if (error instanceof z.ZodError) {
        toast({
          title: 'Validation Error',
          description: error.issues[0].message,
          variant: 'destructive'
        });
      }
      return { success: false, error };
    }
  };

  const secureResetPassword = async (email: string) => {
    try {
      // Validate email format
      const validatedData = loginSchema.pick({ email: true }).parse({ email });
      
      const { error } = await auth.resetPassword(validatedData.email);
      
      if (error) {
        toast({
          title: 'Error',
          description: 'Failed to send reset email. Please try again.',
          variant: 'destructive'
        });
        return { success: false, error };
      }

      // Always show success message for security (don't reveal if email exists)
      toast({
        title: 'Reset Email Sent',
        description: 'If an account exists with this email, you will receive reset instructions.',
      });

      return { success: true, error: null };
    } catch (error) {
      if (error instanceof z.ZodError) {
        toast({
          title: 'Validation Error',
          description: error.issues[0].message,
          variant: 'destructive'
        });
      }
      return { success: false, error };
    }
  };

  return {
    ...auth,
    secureSignIn,
    secureSignUp,
    secureResetPassword
  };
}
