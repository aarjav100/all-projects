import Layout from "@/components/layout/Layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Progress } from "@/components/ui/progress";
import { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { Upload, Home, MapPin, DollarSign, Calendar } from "lucide-react";
import { toast } from "sonner";

const PropertyForm = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const [step, setStep] = useState(1);
  const totalSteps = 5;
  const progress = (step / totalSteps) * 100;

  const amenities = [
    "WiFi", "Kitchen", "Parking", "Pool", "Gym", "Air Conditioning",
    "Heating", "TV", "Washer", "Dryer", "Pet Friendly", "Smoking Allowed"
  ];

  const handleSaveDraft = () => {
    toast.success("Draft saved successfully");
  };

  const handlePublish = () => {
    toast.success("Property published successfully");
    navigate("/host/properties");
  };

  return (
    <Layout>
      <div className="container mx-auto p-4 max-w-4xl space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">{id ? "Edit Property" : "Add New Property"}</h1>
            <p className="text-muted-foreground">Step {step} of {totalSteps}</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={handleSaveDraft}>Save Draft</Button>
            <Button variant="outline" onClick={() => navigate("/host/properties")}>Cancel</Button>
          </div>
        </div>

        <Progress value={progress} className="w-full" />

        {step === 1 && (
          <Card>
            <CardHeader>
              <CardTitle>Property Type</CardTitle>
              <CardDescription>Select the type of property you're listing</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {["Entire Place", "Private Room", "Shared Room"].map((type) => (
                  <div
                    key={type}
                    className="p-6 border-2 rounded-lg cursor-pointer hover:border-primary transition-colors text-center"
                  >
                    <Home className="h-8 w-8 mx-auto mb-2" />
                    <p className="font-medium">{type}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {step === 2 && (
          <Card>
            <CardHeader>
              <CardTitle>Photos & Title</CardTitle>
              <CardDescription>Upload photos and give your property a title</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <Label htmlFor="photos">Property Photos</Label>
                <div className="mt-2 border-2 border-dashed rounded-lg p-8 text-center">
                  <Upload className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                  <p className="text-sm text-muted-foreground mb-4">
                    Drag and drop photos here, or click to browse
                  </p>
                  <Button variant="outline">Upload Photos</Button>
                </div>
              </div>
              <div>
                <Label htmlFor="title">Property Title</Label>
                <Input
                  id="title"
                  placeholder="e.g., Cozy Beach House with Ocean View"
                  className="mt-2"
                />
              </div>
              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  placeholder="Describe your property, its unique features, and what makes it special..."
                  rows={6}
                  className="mt-2"
                />
              </div>
            </CardContent>
          </Card>
        )}

        {step === 3 && (
          <Card>
            <CardHeader>
              <CardTitle>Location & Amenities</CardTitle>
              <CardDescription>Add location and select amenities</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <Label htmlFor="address">Address</Label>
                <Input
                  id="address"
                  placeholder="Enter property address"
                  className="mt-2"
                />
                <p className="text-xs text-muted-foreground mt-1">
                  Exact address will be shown only after booking
                </p>
              </div>
              <div>
                <Label>Amenities</Label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mt-4">
                  {amenities.map((amenity) => (
                    <div key={amenity} className="flex items-center space-x-2">
                      <Checkbox id={amenity} />
                      <Label htmlFor={amenity} className="font-normal cursor-pointer">
                        {amenity}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {step === 4 && (
          <Card>
            <CardHeader>
              <CardTitle>House Rules & Policies</CardTitle>
              <CardDescription>Set rules for your guests</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <Label>House Rules</Label>
                <div className="space-y-3 mt-4">
                  <div className="flex items-center space-x-2">
                    <Checkbox id="pets" />
                    <Label htmlFor="pets" className="font-normal cursor-pointer">
                      Pets allowed
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="smoking" />
                    <Label htmlFor="smoking" className="font-normal cursor-pointer">
                      Smoking allowed
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="events" />
                    <Label htmlFor="events" className="font-normal cursor-pointer">
                      Events allowed
                    </Label>
                  </div>
                </div>
              </div>
              <div>
                <Label htmlFor="checkIn">Check-in Time</Label>
                <Input id="checkIn" type="time" defaultValue="15:00" className="mt-2" />
              </div>
              <div>
                <Label htmlFor="checkOut">Check-out Time</Label>
                <Input id="checkOut" type="time" defaultValue="11:00" className="mt-2" />
              </div>
              <div>
                <Label htmlFor="cancellation">Cancellation Policy</Label>
                <Textarea
                  id="cancellation"
                  placeholder="Describe your cancellation policy..."
                  rows={4}
                  className="mt-2"
                />
              </div>
            </CardContent>
          </Card>
        )}

        {step === 5 && (
          <Card>
            <CardHeader>
              <CardTitle>Pricing & Availability</CardTitle>
              <CardDescription>Set your pricing and availability</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <Label htmlFor="price">Price per Night ($)</Label>
                <Input
                  id="price"
                  type="number"
                  placeholder="100"
                  className="mt-2"
                />
              </div>
              <div>
                <Label htmlFor="cleaningFee">Cleaning Fee ($)</Label>
                <Input
                  id="cleaningFee"
                  type="number"
                  placeholder="50"
                  className="mt-2"
                />
              </div>
              <div>
                <Label htmlFor="minStay">Minimum Stay (nights)</Label>
                <Input
                  id="minStay"
                  type="number"
                  placeholder="1"
                  defaultValue="1"
                  className="mt-2"
                />
              </div>
              <div>
                <Label>Availability Calendar</Label>
                <div className="mt-2 p-4 border rounded-lg text-center text-muted-foreground">
                  <Calendar className="h-12 w-12 mx-auto mb-2" />
                  <p>Calendar will be available after publishing</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        <div className="flex justify-between">
          <Button
            variant="outline"
            onClick={() => setStep(Math.max(1, step - 1))}
            disabled={step === 1}
          >
            Previous
          </Button>
          {step < totalSteps ? (
            <Button onClick={() => setStep(Math.min(totalSteps, step + 1))}>
              Next Step
            </Button>
          ) : (
            <Button onClick={handlePublish}>
              Publish Property
            </Button>
          )}
        </div>
      </div>
    </Layout>
  );
};

export default PropertyForm;
