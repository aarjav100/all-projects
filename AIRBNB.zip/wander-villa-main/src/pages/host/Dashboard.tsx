import Layout from "@/components/layout/Layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { DollarSign, Calendar, MessageSquare, Star, Home, TrendingUp } from "lucide-react";
import { useNavigate } from "react-router-dom";

const Dashboard = () => {
  const navigate = useNavigate();

  const stats = [
    { title: "Total Revenue", value: "$12,450", icon: DollarSign, change: "+12.5%" },
    { title: "Active Bookings", value: "8", icon: Calendar, change: "+2" },
    { title: "Pending Messages", value: "3", icon: MessageSquare, change: "New" },
    { title: "Average Rating", value: "4.8", icon: Star, change: "+0.2" },
  ];

  const upcomingBookings = [
    { guest: "John Doe", property: "Beach Villa", checkIn: "2024-02-15", status: "Confirmed" },
    { guest: "Jane Smith", property: "Mountain Cabin", checkIn: "2024-02-18", status: "Confirmed" },
    { guest: "Bob Wilson", property: "City Apartment", checkIn: "2024-02-20", status: "Pending" },
  ];

  return (
    <Layout>
      <div className="container mx-auto p-4 space-y-6 max-w-7xl">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold">Host Dashboard</h1>
            <p className="text-muted-foreground">Manage your properties and bookings</p>
          </div>
          <Button onClick={() => navigate("/host/property/new")}>
            <Home className="mr-2 h-4 w-4" />
            Add Property
          </Button>
        </div>

        {/* Stats Grid */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {stats.map((stat) => (
            <Card key={stat.title}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
                <stat.icon className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stat.value}</div>
                <p className="text-xs text-success flex items-center mt-1">
                  <TrendingUp className="h-3 w-3 mr-1" />
                  {stat.change}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
            <CardDescription>Frequently used features</CardDescription>
          </CardHeader>
          <CardContent className="flex gap-4 flex-wrap">
            <Button variant="outline" onClick={() => navigate("/host/properties")}>
              <Home className="mr-2 h-4 w-4" />
              Manage Properties
            </Button>
            <Button variant="outline" onClick={() => navigate("/host/calendar")}>
              <Calendar className="mr-2 h-4 w-4" />
              View Calendar
            </Button>
            <Button variant="outline" onClick={() => navigate("/messages")}>
              <MessageSquare className="mr-2 h-4 w-4" />
              Messages
            </Button>
          </CardContent>
        </Card>

        {/* Upcoming Bookings */}
        <Card>
          <CardHeader>
            <CardTitle>Upcoming Check-ins</CardTitle>
            <CardDescription>Guests arriving soon</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {upcomingBookings.map((booking, index) => (
                <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                  <div>
                    <p className="font-medium">{booking.guest}</p>
                    <p className="text-sm text-muted-foreground">{booking.property}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium">{booking.checkIn}</p>
                    <p className="text-xs text-muted-foreground">{booking.status}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Recent Messages */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Messages</CardTitle>
            <CardDescription>Messages requiring response</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[1, 2, 3].map((item) => (
                <div key={item} className="flex items-start gap-4 p-4 border rounded-lg">
                  <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                    <MessageSquare className="h-5 w-5 text-primary" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium">Guest #{item}</p>
                    <p className="text-sm text-muted-foreground">Question about check-in process</p>
                    <p className="text-xs text-muted-foreground mt-1">2 hours ago</p>
                  </div>
                  <Button size="sm" variant="outline">Reply</Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
};

export default Dashboard;
