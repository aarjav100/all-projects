import Layout from "@/components/layout/Layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Plus, Edit, Copy, Eye, Pause, Play } from "lucide-react";
import { useNavigate } from "react-router-dom";

const Properties = () => {
  const navigate = useNavigate();

  const properties = [
    {
      id: 1,
      title: "Luxury Beach Villa",
      location: "Malibu, CA",
      status: "active",
      bookings: 12,
      rating: 4.9,
      revenue: "$8,450",
      image: "/placeholder.svg"
    },
    {
      id: 2,
      title: "Mountain Cabin Retreat",
      location: "Aspen, CO",
      status: "active",
      bookings: 8,
      rating: 4.7,
      revenue: "$6,200",
      image: "/placeholder.svg"
    },
    {
      id: 3,
      title: "Modern City Apartment",
      location: "New York, NY",
      status: "paused",
      bookings: 15,
      rating: 4.8,
      revenue: "$9,800",
      image: "/placeholder.svg"
    },
  ];

  return (
    <Layout>
      <div className="container mx-auto p-4 space-y-6 max-w-7xl">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold">My Properties</h1>
            <p className="text-muted-foreground">Manage your property listings</p>
          </div>
          <Button onClick={() => navigate("/host/property/new")}>
            <Plus className="mr-2 h-4 w-4" />
            Add New Property
          </Button>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {properties.map((property) => (
            <Card key={property.id} className="overflow-hidden">
              <div className="relative">
                <img
                  src={property.image}
                  alt={property.title}
                  className="w-full h-48 object-cover"
                />
                <Badge
                  className="absolute top-2 right-2"
                  variant={property.status === "active" ? "default" : "secondary"}
                >
                  {property.status}
                </Badge>
              </div>
              <CardHeader>
                <CardTitle className="text-lg">{property.title}</CardTitle>
                <CardDescription>{property.location}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-3 gap-2 text-center text-sm">
                  <div>
                    <p className="text-muted-foreground">Bookings</p>
                    <p className="font-bold">{property.bookings}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Rating</p>
                    <p className="font-bold">{property.rating}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Revenue</p>
                    <p className="font-bold">{property.revenue}</p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex-1"
                    onClick={() => navigate(`/property/${property.id}`)}
                  >
                    <Eye className="mr-1 h-4 w-4" />
                    View
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex-1"
                    onClick={() => navigate(`/host/property/${property.id}/edit`)}
                  >
                    <Edit className="mr-1 h-4 w-4" />
                    Edit
                  </Button>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" className="flex-1">
                    <Copy className="mr-1 h-4 w-4" />
                    Duplicate
                  </Button>
                  <Button variant="outline" size="sm" className="flex-1">
                    {property.status === "active" ? (
                      <>
                        <Pause className="mr-1 h-4 w-4" />
                        Pause
                      </>
                    ) : (
                      <>
                        <Play className="mr-1 h-4 w-4" />
                        Activate
                      </>
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </Layout>
  );
};

export default Properties;
