import { useEffect, useState } from "react";
import Layout from "@/components/layout/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, MessageSquare, Archive } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { toast } from "sonner";

interface Conversation {
  id: string;
  participant_one_id: string;
  participant_two_id: string;
  property_id: string | null;
  last_message_at: string | null;
  otherUser?: {
    first_name: string;
    avatar_url: string | null;
  };
  property?: {
    title: string;
  };
  lastMessage?: {
    content: string;
    created_at: string;
  };
  unreadCount?: number;
}

const Messages = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    if (user) {
      fetchConversations();
      subscribeToMessages();
    }
  }, [user]);

  const fetchConversations = async () => {
    try {
      setIsLoading(true);

      const { data, error } = await supabase
        .from('conversations')
        .select(`
          *,
          messages (
            content,
            created_at,
            is_read,
            sender_id
          )
        `)
        .or(`participant_one_id.eq.${user?.id},participant_two_id.eq.${user?.id}`)
        .order('last_message_at', { ascending: false });

      if (error) throw error;

      // Enrich conversations with user and property data
      const enrichedConversations = await Promise.all(
        (data || []).map(async (conv) => {
          const otherUserId = conv.participant_one_id === user?.id 
            ? conv.participant_two_id 
            : conv.participant_one_id;

          // Fetch other user's profile
          const { data: profileData } = await supabase
            .rpc('get_public_profile', { profile_id: otherUserId });

          // Fetch property if exists
          let propertyData = null;
          if (conv.property_id) {
            const { data: propData } = await supabase
              .from('properties')
              .select('title')
              .eq('id', conv.property_id)
              .single();
            propertyData = propData;
          }

          // Get last message and unread count
          const messages = (conv as any).messages || [];
          const lastMessage = messages.length > 0 ? messages[0] : null;
          const unreadCount = messages.filter(
            (msg: any) => !msg.is_read && msg.sender_id !== user?.id
          ).length;

          return {
            ...conv,
            otherUser: profileData?.[0] || { first_name: "User", avatar_url: null },
            property: propertyData,
            lastMessage,
            unreadCount
          };
        })
      );

      setConversations(enrichedConversations);
    } catch (error) {
      console.error("Error fetching conversations:", error);
      toast.error("Failed to load messages");
    } finally {
      setIsLoading(false);
    }
  };

  const subscribeToMessages = () => {
    const channel = supabase
      .channel('messages-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'messages'
        },
        () => {
          fetchConversations();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  };

  const filteredConversations = conversations.filter((conv) =>
    conv.otherUser?.first_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    conv.property?.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const formatTimestamp = (timestamp: string | null) => {
    if (!timestamp) return "";
    
    const date = new Date(timestamp);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffDays === 1) return "Yesterday";
    if (diffDays < 7) return `${diffDays}d ago`;
    return date.toLocaleDateString();
  };

  if (isLoading) {
    return (
      <Layout>
        <div className="container mx-auto p-4 max-w-4xl">
          <Card>
            <CardContent className="p-8">
              <div className="text-center text-muted-foreground">Loading messages...</div>
            </CardContent>
          </Card>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto p-4 max-w-4xl">
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-2xl">Messages</CardTitle>
              <Button variant="outline" size="sm">
                <Archive className="h-4 w-4 mr-2" />
                Archive
              </Button>
            </div>
            <div className="relative mt-4">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search conversations..."
                className="pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </CardHeader>
          <CardContent className="p-0">
            {filteredConversations.length > 0 ? (
              <div className="divide-y">
                {filteredConversations.map((conversation) => (
                  <div
                    key={conversation.id}
                    className="p-4 hover:bg-muted/50 cursor-pointer transition-colors"
                    onClick={() => navigate(`/messages/${conversation.id}`)}
                  >
                    <div className="flex items-start gap-4">
                      <div className="relative">
                        <Avatar className="h-12 w-12">
                          <AvatarImage src={conversation.otherUser?.avatar_url || undefined} />
                          <AvatarFallback>
                            {conversation.otherUser?.first_name?.[0] || "U"}
                          </AvatarFallback>
                        </Avatar>
                        {conversation.unreadCount! > 0 && (
                          <Badge
                            className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0"
                            variant="destructive"
                          >
                            {conversation.unreadCount}
                          </Badge>
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <p className="font-medium">
                              {conversation.otherUser?.first_name || "User"}
                            </p>
                            {conversation.property && (
                              <p className="text-sm text-muted-foreground">
                                {conversation.property.title}
                              </p>
                            )}
                          </div>
                          <span className="text-xs text-muted-foreground whitespace-nowrap ml-2">
                            {formatTimestamp(conversation.lastMessage?.created_at || conversation.last_message_at)}
                          </span>
                        </div>
                        <p className="text-sm text-muted-foreground mt-1 truncate">
                          {conversation.lastMessage?.content || "No messages yet"}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <MessageSquare className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium mb-2">
                  {searchQuery ? "No conversations found" : "No messages yet"}
                </h3>
                <p className="text-muted-foreground">
                  {searchQuery
                    ? "Try a different search term"
                    : "Start a conversation with a host or guest"}
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
};

export default Messages;
