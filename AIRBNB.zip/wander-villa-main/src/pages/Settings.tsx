import { useState } from "react";
import { Bell, Globe, CreditCard, Lock, HelpCircle, FileText, AlertTriangle } from "lucide-react";
import Layout from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";

const Settings = () => {
  const [notifications, setNotifications] = useState({
    bookingUpdates: true,
    messages: true,
    promotions: false,
    reminders: true,
  });

  return (
    <Layout>
      <div className="container mx-auto px-4 py-6 max-w-4xl">
        <h1 className="text-3xl font-bold mb-6">Settings</h1>

        {/* Account Information */}
        <Card className="p-6 mb-6">
          <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <Lock className="h-5 w-5" />
            Account Information
          </h2>
          <div className="space-y-4">
            <div>
              <Label>Email</Label>
              <p className="text-sm text-muted-foreground mt-1">john.doe@example.com</p>
            </div>
            <div>
              <Label>Phone Number</Label>
              <p className="text-sm text-muted-foreground mt-1">+1 (555) 123-4567</p>
            </div>
            <Button variant="outline" className="mt-2">
              Change Password
            </Button>
          </div>
        </Card>

        {/* Notification Preferences */}
        <Card className="p-6 mb-6">
          <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <Bell className="h-5 w-5" />
            Notification Preferences
          </h2>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <Label>Booking updates</Label>
                <p className="text-sm text-muted-foreground">Get notified about booking confirmations and changes</p>
              </div>
              <Switch
                checked={notifications.bookingUpdates}
                onCheckedChange={(checked) =>
                  setNotifications({ ...notifications, bookingUpdates: checked })
                }
              />
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div>
                <Label>Messages</Label>
                <p className="text-sm text-muted-foreground">Receive notifications for new messages</p>
              </div>
              <Switch
                checked={notifications.messages}
                onCheckedChange={(checked) =>
                  setNotifications({ ...notifications, messages: checked })
                }
              />
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div>
                <Label>Promotions and tips</Label>
                <p className="text-sm text-muted-foreground">Get deals and travel inspiration</p>
              </div>
              <Switch
                checked={notifications.promotions}
                onCheckedChange={(checked) =>
                  setNotifications({ ...notifications, promotions: checked })
                }
              />
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div>
                <Label>Reminders</Label>
                <p className="text-sm text-muted-foreground">Important trip reminders and check-in information</p>
              </div>
              <Switch
                checked={notifications.reminders}
                onCheckedChange={(checked) =>
                  setNotifications({ ...notifications, reminders: checked })
                }
              />
            </div>
          </div>
        </Card>

        {/* Language & Currency */}
        <Card className="p-6 mb-6">
          <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <Globe className="h-5 w-5" />
            Language & Currency
          </h2>
          <div className="space-y-4">
            <div>
              <Label>Language</Label>
              <Select defaultValue="en">
                <SelectTrigger className="mt-2">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="en">English</SelectItem>
                  <SelectItem value="es">Español</SelectItem>
                  <SelectItem value="fr">Français</SelectItem>
                  <SelectItem value="de">Deutsch</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Currency</Label>
              <Select defaultValue="usd">
                <SelectTrigger className="mt-2">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="usd">USD - US Dollar</SelectItem>
                  <SelectItem value="eur">EUR - Euro</SelectItem>
                  <SelectItem value="gbp">GBP - British Pound</SelectItem>
                  <SelectItem value="jpy">JPY - Japanese Yen</SelectItem>
                  <SelectItem value="inr">INR - Indian Rupee</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </Card>

        {/* Payment Methods */}
        <Card className="p-6 mb-6">
          <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <CreditCard className="h-5 w-5" />
            Payment Methods
          </h2>
          <p className="text-sm text-muted-foreground mb-4">
            Manage your payment methods for bookings
          </p>
          <Button variant="outline">Add Payment Method</Button>
        </Card>

        {/* Privacy Settings */}
        <Card className="p-6 mb-6">
          <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <Lock className="h-5 w-5" />
            Privacy Settings
          </h2>
          <div className="space-y-3">
            <Button variant="outline" className="w-full justify-start">
              Manage personal data
            </Button>
            <Button variant="outline" className="w-full justify-start">
              Download your data
            </Button>
          </div>
        </Card>

        {/* Help & Support */}
        <Card className="p-6 mb-6">
          <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <HelpCircle className="h-5 w-5" />
            Help & Support
          </h2>
          <div className="space-y-3">
            <Button variant="outline" className="w-full justify-start">
              Help Center
            </Button>
            <Button variant="outline" className="w-full justify-start">
              Contact Support
            </Button>
            <Button variant="outline" className="w-full justify-start">
              <FileText className="mr-2 h-4 w-4" />
              Terms of Service
            </Button>
            <Button variant="outline" className="w-full justify-start">
              <FileText className="mr-2 h-4 w-4" />
              Privacy Policy
            </Button>
          </div>
        </Card>

        {/* Danger Zone */}
        <Card className="p-6 border-destructive/50">
          <h2 className="text-xl font-semibold mb-4 flex items-center gap-2 text-destructive">
            <AlertTriangle className="h-5 w-5" />
            Danger Zone
          </h2>
          <p className="text-sm text-muted-foreground mb-4">
            Once you delete your account, there is no going back. Please be certain.
          </p>
          <Button variant="destructive">Delete Account</Button>
        </Card>
      </div>
    </Layout>
  );
};

export default Settings;
