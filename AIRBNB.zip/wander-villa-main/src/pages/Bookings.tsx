import { useState, useEffect } from "react";
import { Calendar, MessageSquare, FileEdit, XCircle, Star } from "lucide-react";
import Layout from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";

interface Booking {
  id: string;
  property_id: string;
  check_in_date: string;
  check_out_date: string;
  guest_count: number;
  total_price: number;
  status: string;
  booking_reference: string;
  special_requests?: string;
  properties: {
    id: string;
    title: string;
    city: string;
    property_images?: { image_url: string }[];
  };
}

const Bookings = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("upcoming");
  const [bookings, setBookings] = useState<{
    upcoming: Booking[];
    past: Booking[];
    cancelled: Booking[];
  }>({
    upcoming: [],
    past: [],
    cancelled: [],
  });
  const [isLoading, setIsLoading] = useState(true);
  const [selectedBooking, setSelectedBooking] = useState<Booking | null>(null);
  const [showModifyDialog, setShowModifyDialog] = useState(false);
  const [showCancelDialog, setShowCancelDialog] = useState(false);
  const [modifyData, setModifyData] = useState({
    check_in_date: "",
    check_out_date: "",
    guest_count: 1,
    special_requests: "",
  });
  const [cancellationReason, setCancellationReason] = useState("");

  useEffect(() => {
    if (user) {
      fetchBookings();
    }
  }, [user]);

  const fetchBookings = async () => {
    try {
      setIsLoading(true);
      const { data, error } = await supabase
        .from("bookings")
        .select(`
          *,
          properties (
            id,
            title,
            city,
            property_images (
              image_url
            )
          )
        `)
        .eq("guest_id", user?.id)
        .order("created_at", { ascending: false });

      if (error) throw error;

      const now = new Date();
      const categorized = {
        upcoming: [] as Booking[],
        past: [] as Booking[],
        cancelled: [] as Booking[],
      };

      (data || []).forEach((booking: any) => {
        if (booking.status === "cancelled") {
          categorized.cancelled.push(booking);
        } else if (new Date(booking.check_in_date) > now) {
          categorized.upcoming.push(booking);
        } else {
          categorized.past.push(booking);
        }
      });

      setBookings(categorized);
    } catch (error) {
      console.error("Error fetching bookings:", error);
      toast.error("Failed to load bookings");
    } finally {
      setIsLoading(false);
    }
  };

  const handleModifyBooking = async () => {
    if (!selectedBooking) return;

    try {
      const { error } = await supabase
        .from("bookings")
        .update({
          check_in_date: modifyData.check_in_date,
          check_out_date: modifyData.check_out_date,
          guest_count: modifyData.guest_count,
          special_requests: modifyData.special_requests,
        })
        .eq("id", selectedBooking.id);

      if (error) throw error;

      toast.success("Booking modified successfully");
      setShowModifyDialog(false);
      fetchBookings();
    } catch (error) {
      console.error("Error modifying booking:", error);
      toast.error("Failed to modify booking");
    }
  };

  const handleCancelBooking = async () => {
    if (!selectedBooking) return;

    try {
      const { error } = await supabase
        .from("bookings")
        .update({
          status: "cancelled",
          cancellation_reason: cancellationReason,
          cancelled_at: new Date().toISOString(),
        })
        .eq("id", selectedBooking.id);

      if (error) throw error;

      toast.success("Booking cancelled successfully");
      setShowCancelDialog(false);
      fetchBookings();
    } catch (error) {
      console.error("Error cancelling booking:", error);
      toast.error("Failed to cancel booking");
    }
  };

  const openModifyDialog = (booking: Booking) => {
    setSelectedBooking(booking);
    setModifyData({
      check_in_date: booking.check_in_date,
      check_out_date: booking.check_out_date,
      guest_count: booking.guest_count,
      special_requests: booking.special_requests || "",
    });
    setShowModifyDialog(true);
  };

  const openCancelDialog = (booking: Booking) => {
    setSelectedBooking(booking);
    setCancellationReason("");
    setShowCancelDialog(true);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-IN", {
      year: "numeric",
      month: "short",
      day: "numeric",
    });
  };

  const renderBookingCard = (booking: Booking, showActions: boolean = true) => {
    const imageUrl =
      booking.properties.property_images && booking.properties.property_images.length > 0
        ? booking.properties.property_images[0].image_url
        : "/placeholder.svg";

    return (
      <Card key={booking.id} className="p-4 mb-4">
        <div className="flex flex-col sm:flex-row gap-4">
          {/* Property Image */}
          <img
            src={imageUrl}
            alt={booking.properties.title}
            className="w-full sm:w-32 h-32 rounded-lg object-cover cursor-pointer"
            onClick={() => navigate(`/property/${booking.property_id}`)}
          />

          {/* Booking Details */}
          <div className="flex-1">
            <div className="flex items-start justify-between mb-2">
              <div>
                <h3 className="font-semibold text-lg">{booking.properties.title}</h3>
                <p className="text-sm text-muted-foreground">{booking.properties.city}</p>
              </div>
              <Badge
                variant={
                  booking.status === "confirmed"
                    ? "default"
                    : booking.status === "cancelled"
                    ? "destructive"
                    : "secondary"
                }
              >
                {booking.status}
              </Badge>
            </div>

            <div className="text-sm space-y-1 mb-3">
              <p>
                <span className="text-muted-foreground">Booking ref:</span>{" "}
                <span className="font-medium">{booking.booking_reference}</span>
              </p>
              <p>
                <span className="text-muted-foreground">Dates:</span>{" "}
                <span className="font-medium">
                  {formatDate(booking.check_in_date)} - {formatDate(booking.check_out_date)}
                </span>
              </p>
              <p>
                <span className="text-muted-foreground">Guests:</span>{" "}
                <span className="font-medium">{booking.guest_count}</span>
              </p>
              <p className="font-semibold">Total: ₹{booking.total_price}</p>
            </div>

            {/* Action Buttons */}
            {showActions && (
              <div className="flex flex-wrap gap-2">
                {booking.status === "confirmed" && (
                  <>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => openModifyDialog(booking)}
                    >
                      <FileEdit className="mr-2 h-4 w-4" />
                      Modify
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => navigate("/messages")}>
                      <MessageSquare className="mr-2 h-4 w-4" />
                      Contact Host
                    </Button>
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => openCancelDialog(booking)}
                    >
                      <XCircle className="mr-2 h-4 w-4" />
                      Cancel
                    </Button>
                  </>
                )}
                {booking.status === "completed" && (
                  <Button size="sm">
                    <Star className="mr-2 h-4 w-4" />
                    Leave Review
                  </Button>
                )}
              </div>
            )}
          </div>
        </div>
      </Card>
    );
  };

  const EmptyState = ({ message }: { message: string }) => (
    <div className="text-center py-12">
      <Calendar className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
      <p className="text-muted-foreground mb-4">{message}</p>
      <Button onClick={() => navigate("/")}>Start Searching</Button>
    </div>
  );

  if (isLoading) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-6 max-w-4xl">
          <h1 className="text-3xl font-bold mb-6">My Bookings</h1>
          <div className="text-center py-12 text-muted-foreground">Loading bookings...</div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto px-4 py-6 max-w-4xl">
        <h1 className="text-3xl font-bold mb-6">My Bookings</h1>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-3 mb-6">
            <TabsTrigger value="upcoming">Upcoming ({bookings.upcoming.length})</TabsTrigger>
            <TabsTrigger value="past">Past ({bookings.past.length})</TabsTrigger>
            <TabsTrigger value="cancelled">Cancelled ({bookings.cancelled.length})</TabsTrigger>
          </TabsList>

          <TabsContent value="upcoming">
            {bookings.upcoming.length > 0 ? (
              bookings.upcoming.map((booking) => renderBookingCard(booking))
            ) : (
              <EmptyState message="You don't have any upcoming bookings" />
            )}
          </TabsContent>

          <TabsContent value="past">
            {bookings.past.length > 0 ? (
              bookings.past.map((booking) => renderBookingCard(booking))
            ) : (
              <EmptyState message="You don't have any past bookings" />
            )}
          </TabsContent>

          <TabsContent value="cancelled">
            {bookings.cancelled.length > 0 ? (
              bookings.cancelled.map((booking) => renderBookingCard(booking, false))
            ) : (
              <EmptyState message="You don't have any cancelled bookings" />
            )}
          </TabsContent>
        </Tabs>
      </div>

      {/* Modify Booking Dialog */}
      <Dialog open={showModifyDialog} onOpenChange={setShowModifyDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Modify Booking</DialogTitle>
            <DialogDescription>Update your booking details below.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="check_in">Check-in Date</Label>
              <Input
                id="check_in"
                type="date"
                value={modifyData.check_in_date}
                onChange={(e) => setModifyData({ ...modifyData, check_in_date: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="check_out">Check-out Date</Label>
              <Input
                id="check_out"
                type="date"
                value={modifyData.check_out_date}
                onChange={(e) => setModifyData({ ...modifyData, check_out_date: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="guests">Number of Guests</Label>
              <Input
                id="guests"
                type="number"
                min="1"
                value={modifyData.guest_count}
                onChange={(e) =>
                  setModifyData({ ...modifyData, guest_count: parseInt(e.target.value) })
                }
              />
            </div>
            <div>
              <Label htmlFor="requests">Special Requests</Label>
              <Textarea
                id="requests"
                value={modifyData.special_requests}
                onChange={(e) => setModifyData({ ...modifyData, special_requests: e.target.value })}
                placeholder="Any special requirements?"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowModifyDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleModifyBooking}>Save Changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Cancel Booking Dialog */}
      <Dialog open={showCancelDialog} onOpenChange={setShowCancelDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Cancel Booking</DialogTitle>
            <DialogDescription>
              Are you sure you want to cancel this booking? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="reason">Cancellation Reason (Optional)</Label>
              <Textarea
                id="reason"
                value={cancellationReason}
                onChange={(e) => setCancellationReason(e.target.value)}
                placeholder="Let us know why you're cancelling..."
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCancelDialog(false)}>
              Keep Booking
            </Button>
            <Button variant="destructive" onClick={handleCancelBooking}>
              Cancel Booking
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Layout>
  );
};

export default Bookings;
