import { useState } from "react";
import Layout from "@/components/layout/Layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Search, MessageCircle, BookOpen, Shield, Phone } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { supportTicketSchema } from "@/lib/validation-schemas";

const Help = () => {
  const { user } = useAuth();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: ""
  });

  const faqs = [
    {
      question: "How do I create a listing?",
      answer: "To create a listing, go to 'Become a Host' in the menu, then follow the step-by-step guide to add your property details, photos, pricing, and availability."
    },
    {
      question: "What are the cancellation policies?",
      answer: "We offer flexible, moderate, and strict cancellation policies. You can choose which policy works best for your property when creating your listing."
    },
    {
      question: "How do I receive payments?",
      answer: "Payments are automatically processed through our secure payment system. You'll receive your earnings 24 hours after guest check-in, minus our service fee."
    },
    {
      question: "How do I communicate with guests?",
      answer: "Use our built-in messaging system to communicate with guests. You'll receive notifications for new messages and can respond directly through the app."
    },
    {
      question: "What if there's damage to my property?",
      answer: "All bookings include host protection insurance. Report any damage within 14 days of checkout, and we'll help you file a claim."
    },
    {
      question: "How do I manage my calendar?",
      answer: "Access your calendar from the host dashboard to block dates, adjust pricing, and sync with external calendars like Airbnb or Booking.com."
    },
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      setIsSubmitting(true);
      
      // Validate form data
      const validation = supportTicketSchema.safeParse(formData);
      if (!validation.success) {
        toast.error(validation.error.issues[0].message);
        return;
      }

      // Submit support ticket
      const { error } = await supabase
        .from('support_tickets')
        .insert([{
          user_id: user?.id || null,
          name: formData.name,
          email: formData.email,
          subject: formData.subject,
          message: formData.message,
        }]);

      if (error) throw error;

      toast.success("Support request submitted successfully! We'll get back to you within 24 hours.");
      setFormData({ name: "", email: "", subject: "", message: "" });
    } catch (error: any) {
      console.error("Error submitting support ticket:", error);
      toast.error("Failed to submit support request. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Layout>
      <div className="container mx-auto p-4 max-w-6xl space-y-8">
        <div className="text-center space-y-4">
          <h1 className="text-4xl font-bold">How can we help you?</h1>
          <p className="text-muted-foreground">
            Search our help articles or contact support
          </p>
          <div className="max-w-2xl mx-auto relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
            <Input
              placeholder="Search for help..."
              className="pl-10 h-12 text-base"
            />
          </div>
        </div>

        <div className="grid gap-6 md:grid-cols-4">
          <Card className="cursor-pointer hover:bg-muted/50 transition-colors">
            <CardContent className="pt-6 text-center">
              <BookOpen className="h-8 w-8 mx-auto mb-3 text-primary" />
              <h3 className="font-medium mb-1">Getting Started</h3>
              <p className="text-sm text-muted-foreground">Learn the basics</p>
            </CardContent>
          </Card>
          <Card className="cursor-pointer hover:bg-muted/50 transition-colors">
            <CardContent className="pt-6 text-center">
              <MessageCircle className="h-8 w-8 mx-auto mb-3 text-primary" />
              <h3 className="font-medium mb-1">Contact Support</h3>
              <p className="text-sm text-muted-foreground">We're here to help</p>
            </CardContent>
          </Card>
          <Card className="cursor-pointer hover:bg-muted/50 transition-colors">
            <CardContent className="pt-6 text-center">
              <Shield className="h-8 w-8 mx-auto mb-3 text-primary" />
              <h3 className="font-medium mb-1">Safety Center</h3>
              <p className="text-sm text-muted-foreground">Stay safe & secure</p>
            </CardContent>
          </Card>
          <Card className="cursor-pointer hover:bg-muted/50 transition-colors">
            <CardContent className="pt-6 text-center">
              <Phone className="h-8 w-8 mx-auto mb-3 text-primary" />
              <h3 className="font-medium mb-1">Call Us</h3>
              <p className="text-sm text-muted-foreground">1-800-SEARCH</p>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Frequently Asked Questions</CardTitle>
            <CardDescription>Quick answers to common questions</CardDescription>
          </CardHeader>
          <CardContent>
            <Accordion type="single" collapsible className="w-full">
              {faqs.map((faq, index) => (
                <AccordionItem key={index} value={`item-${index}`}>
                  <AccordionTrigger>{faq.question}</AccordionTrigger>
                  <AccordionContent>{faq.answer}</AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Contact Support</CardTitle>
            <CardDescription>
              Can't find what you're looking for? Send us a message
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="name">Name</Label>
                <Input 
                  id="name" 
                  placeholder="Your name" 
                  className="mt-2" 
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  required 
                />
              </div>
              <div>
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="your@email.com"
                  className="mt-2"
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                  required
                />
              </div>
              <div>
                <Label htmlFor="subject">Subject</Label>
                <Input
                  id="subject"
                  placeholder="What's this about?"
                  className="mt-2"
                  value={formData.subject}
                  onChange={(e) => setFormData({...formData, subject: e.target.value})}
                  required
                />
              </div>
              <div>
                <Label htmlFor="message">Message</Label>
                <Textarea
                  id="message"
                  placeholder="Describe your issue in detail..."
                  rows={6}
                  className="mt-2"
                  value={formData.message}
                  onChange={(e) => setFormData({...formData, message: e.target.value})}
                  required
                />
              </div>
              <Button type="submit" className="w-full" disabled={isSubmitting}>
                {isSubmitting ? "Submitting..." : "Submit Request"}
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Community Guidelines</CardTitle>
            <CardDescription>Our commitment to safety and respect</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm">
              searchKaro is built on trust. Both hosts and guests are expected to treat each other with respect and follow our community guidelines.
            </p>
            <ul className="list-disc list-inside space-y-2 text-sm text-muted-foreground">
              <li>Be honest and accurate in your listings and communications</li>
              <li>Treat properties and guests with respect</li>
              <li>Communicate clearly and respond promptly</li>
              <li>Follow house rules and local laws</li>
              <li>Report any issues or concerns immediately</li>
            </ul>
            <Button variant="outline" className="w-full">
              Read Full Guidelines
            </Button>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
};

export default Help;
