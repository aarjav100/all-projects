import { useParams, useNavigate } from "react-router-dom";
import { CheckCircle, Calendar, Download } from "lucide-react";
import Layout from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

const BookingConfirmation = () => {
  const { bookingId } = useParams();
  const navigate = useNavigate();

  // Mock booking data
  const booking = {
    id: bookingId,
    reference: "BK" + Math.random().toString(36).substr(2, 9).toUpperCase(),
    property: {
      title: "Luxury Beach Villa",
      image: "/placeholder.svg",
      address: "123 Ocean Drive, Miami Beach, FL",
    },
    checkIn: "Dec 20, 2024",
    checkOut: "Dec 27, 2024",
    guests: 2,
    total: 1935,
    host: {
      name: "John Doe",
      phone: "+1 (555) 123-4567",
      email: "john.doe@example.com",
    },
    instructions: "Check-in time is 3:00 PM. Please call the host 30 minutes before arrival.",
  };

  return (
    <Layout showNav={false}>
      <div className="container mx-auto px-4 py-12 max-w-2xl">
        {/* Success Icon */}
        <div className="text-center mb-8">
          <CheckCircle className="w-20 h-20 mx-auto text-success mb-4" />
          <h1 className="text-3xl font-bold mb-2">Booking Confirmed!</h1>
          <p className="text-muted-foreground">
            Your reservation has been successfully confirmed
          </p>
        </div>

        {/* Booking Reference */}
        <Card className="p-6 mb-6 text-center bg-muted/50">
          <p className="text-sm text-muted-foreground mb-1">Booking Reference</p>
          <p className="text-2xl font-bold">{booking.reference}</p>
        </Card>

        {/* Property Details */}
        <Card className="p-6 mb-6">
          <div className="flex gap-4 mb-6">
            <img
              src={booking.property.image}
              alt={booking.property.title}
              className="w-24 h-24 rounded-lg object-cover"
            />
            <div>
              <h3 className="font-semibold text-lg">{booking.property.title}</h3>
              <p className="text-sm text-muted-foreground">{booking.property.address}</p>
            </div>
          </div>

          <div className="space-y-3 border-t pt-4">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Check-in</span>
              <span className="font-medium">{booking.checkIn}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Check-out</span>
              <span className="font-medium">{booking.checkOut}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Guests</span>
              <span className="font-medium">{booking.guests}</span>
            </div>
            <div className="flex justify-between font-semibold text-lg border-t pt-3">
              <span>Total Paid</span>
              <span>${booking.total}</span>
            </div>
          </div>
        </Card>

        {/* Host Contact */}
        <Card className="p-6 mb-6">
          <h3 className="font-semibold text-lg mb-4">Host Contact Information</h3>
          <div className="space-y-2">
            <p><span className="text-muted-foreground">Name:</span> {booking.host.name}</p>
            <p><span className="text-muted-foreground">Phone:</span> {booking.host.phone}</p>
            <p><span className="text-muted-foreground">Email:</span> {booking.host.email}</p>
          </div>
        </Card>

        {/* Check-in Instructions */}
        <Card className="p-6 mb-6 bg-accent/50">
          <h3 className="font-semibold text-lg mb-2">Check-in Instructions</h3>
          <p className="text-sm">{booking.instructions}</p>
        </Card>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-3">
          <Button variant="outline" className="flex-1" onClick={() => {}}>
            <Calendar className="mr-2 h-4 w-4" />
            Add to Calendar
          </Button>
          <Button variant="outline" className="flex-1" onClick={() => {}}>
            <Download className="mr-2 h-4 w-4" />
            Download Details
          </Button>
        </div>

        <div className="mt-6 flex flex-col gap-3">
          <Button onClick={() => navigate(`/property/${bookingId}`)}>
            View Booking Details
          </Button>
          <Button variant="secondary" onClick={() => navigate("/")}>
            Book Another Stay
          </Button>
        </div>
      </div>
    </Layout>
  );
};

export default BookingConfirmation;
