import { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { format } from "date-fns";
import { CalendarIcon, Minus, Plus } from "lucide-react";
import Layout from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";

const Booking = () => {
  const { propertyId } = useParams();
  const navigate = useNavigate();
  
  const [checkIn, setCheckIn] = useState<Date>();
  const [checkOut, setCheckOut] = useState<Date>();
  const [guests, setGuests] = useState(1);
  const [specialRequests, setSpecialRequests] = useState("");
  const [agreedToTerms, setAgreedToTerms] = useState(false);

  // Mock property data
  const property = {
    id: propertyId,
    title: "Luxury Beach Villa",
    image: "/placeholder.svg",
    pricePerNight: 250,
    cleaningFee: 50,
    serviceFee: 35,
  };

  const nights = checkIn && checkOut ? Math.ceil((checkOut.getTime() - checkIn.getTime()) / (1000 * 60 * 60 * 24)) : 0;
  const subtotal = nights * property.pricePerNight;
  const total = subtotal + property.cleaningFee + property.serviceFee;

  const handleConfirmBooking = () => {
    if (!checkIn || !checkOut || !agreedToTerms) return;
    navigate(`/booking/confirmation/${propertyId}`);
  };

  return (
    <Layout>
      <div className="container mx-auto px-4 py-6 max-w-4xl">
        <h1 className="text-3xl font-bold mb-6">Confirm and pay</h1>

        {/* Property Summary Card */}
        <Card className="p-4 mb-6">
          <div className="flex gap-4">
            <img
              src={property.image}
              alt={property.title}
              className="w-24 h-24 rounded-lg object-cover"
            />
            <div>
              <h3 className="font-semibold text-lg">{property.title}</h3>
              <p className="text-muted-foreground">${property.pricePerNight} / night</p>
            </div>
          </div>
        </Card>

        {/* Trip Details */}
        <Card className="p-6 mb-6">
          <h2 className="text-xl font-semibold mb-4">Your trip</h2>
          
          <div className="space-y-4">
            {/* Check-in Date */}
            <div>
              <Label>Check-in</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal mt-2",
                      !checkIn && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {checkIn ? format(checkIn, "PPP") : "Select check-in date"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={checkIn}
                    onSelect={setCheckIn}
                    disabled={(date) => date < new Date()}
                    initialFocus
                    className="pointer-events-auto"
                  />
                </PopoverContent>
              </Popover>
            </div>

            {/* Check-out Date */}
            <div>
              <Label>Check-out</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal mt-2",
                      !checkOut && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {checkOut ? format(checkOut, "PPP") : "Select check-out date"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={checkOut}
                    onSelect={setCheckOut}
                    disabled={(date) => !checkIn || date <= checkIn}
                    initialFocus
                    className="pointer-events-auto"
                  />
                </PopoverContent>
              </Popover>
            </div>

            {/* Guest Count */}
            <div>
              <Label>Guests</Label>
              <div className="flex items-center gap-4 mt-2">
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => setGuests(Math.max(1, guests - 1))}
                >
                  <Minus className="h-4 w-4" />
                </Button>
                <span className="font-semibold text-lg w-12 text-center">{guests}</span>
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => setGuests(guests + 1)}
                >
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {/* Special Requests */}
            <div>
              <Label htmlFor="requests">Special requests (optional)</Label>
              <Textarea
                id="requests"
                placeholder="Any special requests or requirements?"
                value={specialRequests}
                onChange={(e) => setSpecialRequests(e.target.value)}
                className="mt-2"
              />
            </div>
          </div>
        </Card>

        {/* Price Breakdown */}
        <Card className="p-6 mb-6">
          <h2 className="text-xl font-semibold mb-4">Price details</h2>
          
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-muted-foreground">
                ${property.pricePerNight} × {nights} nights
              </span>
              <span>${subtotal}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Cleaning fee</span>
              <span>${property.cleaningFee}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Service fee</span>
              <span>${property.serviceFee}</span>
            </div>
            <div className="border-t pt-3 flex justify-between font-semibold text-lg">
              <span>Total</span>
              <span>${total}</span>
            </div>
          </div>
        </Card>

        {/* Terms and Conditions */}
        <div className="flex items-start gap-2 mb-6">
          <Checkbox
            id="terms"
            checked={agreedToTerms}
            onCheckedChange={(checked) => setAgreedToTerms(checked as boolean)}
          />
          <Label htmlFor="terms" className="text-sm leading-relaxed cursor-pointer">
            I agree to the cancellation policy, house rules, and terms of service
          </Label>
        </div>

        {/* Confirm Button */}
        <Button
          className="w-full"
          size="lg"
          disabled={!checkIn || !checkOut || !agreedToTerms}
          onClick={handleConfirmBooking}
        >
          Confirm and pay
        </Button>
      </div>
    </Layout>
  );
};

export default Booking;
