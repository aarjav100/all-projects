import { useState, useEffect } from "react";
import { Heart, Share2, Search, Star } from "lucide-react";
import { useNavigate } from "react-router-dom";
import Layout from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";

interface Property {
  id: string;
  title: string;
  city: string;
  price_per_night: number;
  images?: { image_url: string }[];
}

interface Favorite {
  id: string;
  property_id: string;
  properties: Property;
}

const Favorites = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [favorites, setFavorites] = useState<Favorite[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchFavorites();
    }
  }, [user]);

  const fetchFavorites = async () => {
    try {
      setIsLoading(true);
      const { data, error } = await supabase
        .from('favorites')
        .select(`
          id,
          property_id,
          properties (
            id,
            title,
            city,
            price_per_night,
            property_images (
              image_url
            )
          )
        `)
        .eq('user_id', user?.id);

      if (error) throw error;

      setFavorites(data as any || []);
    } catch (error) {
      console.error("Error fetching favorites:", error);
      toast.error("Failed to load favorites");
    } finally {
      setIsLoading(false);
    }
  };

  const removeFavorite = async (favoriteId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    
    try {
      const { error } = await supabase
        .from('favorites')
        .delete()
        .eq('id', favoriteId);

      if (error) throw error;

      setFavorites(favorites.filter((fav) => fav.id !== favoriteId));
      toast.success("Removed from favorites");
    } catch (error) {
      console.error("Error removing favorite:", error);
      toast.error("Failed to remove favorite");
    }
  };

  const EmptyState = () => (
    <div className="text-center py-16">
      <Heart className="w-20 h-20 mx-auto text-muted-foreground mb-4" />
      <h2 className="text-2xl font-semibold mb-2">No favorites yet</h2>
      <p className="text-muted-foreground mb-6">
        Start adding properties you love to your favorites
      </p>
      <Button onClick={() => navigate("/")}>
        <Search className="mr-2 h-4 w-4" />
        Start Searching
      </Button>
    </div>
  );

  if (isLoading) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-6 max-w-6xl">
          <h1 className="text-3xl font-bold mb-6">My Favorites</h1>
          <div className="text-center py-12 text-muted-foreground">
            Loading favorites...
          </div>
        </div>
      </Layout>
    );
  }

  if (favorites.length === 0) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-6 max-w-6xl">
          <h1 className="text-3xl font-bold mb-6">My Favorites</h1>
          <EmptyState />
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto px-4 py-6 max-w-6xl">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-3xl font-bold">My Favorites</h1>
          <Button variant="outline">
            <Share2 className="mr-2 h-4 w-4" />
            Share Wishlist
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {favorites.map((favorite) => {
            const property = favorite.properties;
            const imageUrl = (property.images && property.images.length > 0)
              ? property.images[0].image_url
              : '/placeholder.svg';

            return (
              <Card
                key={favorite.id}
                className="overflow-hidden cursor-pointer hover:shadow-lg transition-shadow"
                onClick={() => navigate(`/property/${property.id}`)}
              >
                <div className="relative">
                  <img
                    src={imageUrl}
                    alt={property.title}
                    className="w-full h-48 object-cover"
                  />
                  <Button
                    variant="ghost"
                    size="icon"
                    className="absolute top-2 right-2 bg-white/90 hover:bg-white"
                    onClick={(e) => removeFavorite(favorite.id, e)}
                  >
                    <Heart className="h-5 w-5 fill-primary text-primary" />
                  </Button>
                </div>

                <div className="p-4">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold line-clamp-1">{property.title}</h3>
                      <p className="text-sm text-muted-foreground">{property.city}</p>
                    </div>
                    <Badge variant="secondary" className="flex items-center gap-1 shrink-0">
                      <Star className="w-3 h-3 fill-warning text-warning" />
                      4.8
                    </Badge>
                  </div>

                  <div className="flex items-center justify-between mt-3">
                    <div>
                      <span className="font-semibold text-lg">₹{property.price_per_night}</span>
                      <span className="text-muted-foreground text-sm"> / night</span>
                    </div>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>

        {/* Create Multiple Wishlists */}
        <Card className="mt-8 p-6 bg-accent/50 text-center">
          <h3 className="text-lg font-semibold mb-2">Organize your favorites</h3>
          <p className="text-sm text-muted-foreground mb-4">
            Create multiple wishlists to organize your saved properties
          </p>
          <Button variant="outline">Create New Wishlist</Button>
        </Card>
      </div>
    </Layout>
  );
};

export default Favorites;
