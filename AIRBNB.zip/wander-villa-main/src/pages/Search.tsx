import { useState } from "react";
import Layout from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { SlidersHorizontal, Map as MapIcon, List, Star, Heart, Search as SearchIcon } from "lucide-react";
import { Link } from "react-router-dom";
import SearchFilters from "@/components/search/SearchFilters";
import SearchMap from "@/components/search/SearchMap";

const Search = () => {
  const [viewMode, setViewMode] = useState<"list" | "map">("list");
  const [showFilters, setShowFilters] = useState(false);
  const [activeFilters, setActiveFilters] = useState(0);
  const [favorites, setFavorites] = useState<number[]>([]);

  const properties = [
    {
      id: 1,
      title: "Luxury Apartment with Sea View",
      location: "Marine Drive, Mumbai",
      price: 12500,
      rating: 4.9,
      reviews: 156,
      image: "https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=600",
      type: "Entire place",
      beds: 2,
      baths: 2,
      verified: true,
      lat: 18.9432,
      lng: 72.8236,
    },
    {
      id: 2,
      title: "Heritage Villa in Pink City",
      location: "Jaipur, Rajasthan",
      price: 8300,
      rating: 4.8,
      reviews: 98,
      image: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=600",
      type: "Entire place",
      beds: 3,
      baths: 2,
      verified: true,
      lat: 26.9124,
      lng: 75.7873,
    },
    {
      id: 3,
      title: "Cozy Studio in Tech Hub",
      location: "Koramangala, Bangalore",
      price: 7900,
      rating: 4.6,
      reviews: 203,
      image: "https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=600",
      type: "Private room",
      beds: 1,
      baths: 1,
      verified: false,
      lat: 12.9352,
      lng: 77.6245,
    },
    {
      id: 4,
      title: "Beachfront Villa with Pool",
      location: "Candolim, Goa",
      price: 15800,
      rating: 5.0,
      reviews: 67,
      image: "https://images.unsplash.com/photo-1582268611958-ebfd161ef9cf?w=600",
      type: "Entire place",
      beds: 4,
      baths: 3,
      verified: true,
      lat: 15.5177,
      lng: 73.7622,
    },
    {
      id: 5,
      title: "Palace View Heritage Home",
      location: "Udaipur, Rajasthan",
      price: 10400,
      rating: 4.7,
      reviews: 142,
      image: "https://images.unsplash.com/photo-1564013799919-ab600027ffc6?w=600",
      type: "Entire place",
      beds: 2,
      baths: 1,
      verified: true,
      lat: 24.5854,
      lng: 73.7125,
    },
    {
      id: 6,
      title: "Modern Penthouse in Capital",
      location: "Connaught Place, Delhi",
      price: 22800,
      rating: 4.9,
      reviews: 89,
      image: "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=600",
      type: "Entire place",
      beds: 3,
      baths: 2,
      verified: true,
      lat: 28.6315,
      lng: 77.2167,
    },
  ];

  const toggleFavorite = (id: number) => {
    setFavorites(prev => 
      prev.includes(id) ? prev.filter(fav => fav !== id) : [...prev, id]
    );
  };

  return (
    <Layout>
      <div className="space-y-4">
        {/* Search Bar */}
        <div className="bg-card border-b border-border px-4 py-3 space-y-3">
          <div className="max-w-6xl mx-auto space-y-3">
            <div className="flex gap-2">
              <div className="relative flex-1">
                <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input 
                  placeholder="Search destinations..." 
                  className="pl-9"
                  defaultValue="New York"
                />
              </div>
              <Button
                variant="outline"
                size="icon"
                onClick={() => setShowFilters(true)}
                className="relative"
              >
                <SlidersHorizontal className="w-4 h-4" />
                {activeFilters > 0 && (
                  <Badge 
                    variant="destructive" 
                    className="absolute -top-2 -right-2 h-5 w-5 p-0 flex items-center justify-center text-xs"
                  >
                    {activeFilters}
                  </Badge>
                )}
              </Button>
            </div>

            <div className="flex items-center justify-between">
              <div className="text-sm text-muted-foreground">
                {properties.length} properties found
              </div>
              
              <div className="flex items-center gap-2">
                <Select defaultValue="recommended">
                  <SelectTrigger className="w-40 h-9">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="recommended">Recommended</SelectItem>
                    <SelectItem value="price-low">Price: Low to High</SelectItem>
                    <SelectItem value="price-high">Price: High to Low</SelectItem>
                    <SelectItem value="rating">Highest Rated</SelectItem>
                  </SelectContent>
                </Select>

                <div className="flex rounded-md border border-border overflow-hidden">
                  <Button
                    variant={viewMode === "list" ? "secondary" : "ghost"}
                    size="sm"
                    onClick={() => setViewMode("list")}
                    className="rounded-none"
                  >
                    <List className="w-4 h-4" />
                  </Button>
                  <Button
                    variant={viewMode === "map" ? "secondary" : "ghost"}
                    size="sm"
                    onClick={() => setViewMode("map")}
                    className="rounded-none border-l"
                  >
                    <MapIcon className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="px-4 pb-8">
          <div className="max-w-6xl mx-auto">
            {viewMode === "list" ? (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {properties.map((property) => (
                  <Card key={property.id} className="overflow-hidden group">
                    <Link to={`/property/${property.id}`}>
                      <div className="aspect-[4/3] relative">
                        <img
                          src={property.image}
                          alt={property.title}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                        <button
                          onClick={(e) => {
                            e.preventDefault();
                            toggleFavorite(property.id);
                          }}
                          className="absolute top-3 right-3 bg-white/90 backdrop-blur-sm rounded-full p-2 hover:bg-white transition-colors"
                        >
                          <Heart
                            className={`w-5 h-5 ${
                              favorites.includes(property.id)
                                ? "fill-primary text-primary"
                                : "text-foreground"
                            }`}
                          />
                        </button>
                        {property.verified && (
                          <Badge className="absolute top-3 left-3 bg-white/90 backdrop-blur-sm text-foreground hover:bg-white">
                            Verified
                          </Badge>
                        )}
                      </div>
                    </Link>
                    
                    <div className="p-4 space-y-2">
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex-1 min-w-0">
                          <Link to={`/property/${property.id}`}>
                            <h3 className="font-semibold text-base truncate hover:text-primary transition-colors">
                              {property.title}
                            </h3>
                          </Link>
                          <p className="text-sm text-muted-foreground truncate">
                            {property.location}
                          </p>
                        </div>
                        <div className="flex items-center gap-1 text-sm shrink-0">
                          <Star className="w-4 h-4 fill-warning text-warning" />
                          <span className="font-medium">{property.rating}</span>
                          <span className="text-muted-foreground">({property.reviews})</span>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <span>{property.type}</span>
                        <span>•</span>
                        <span>{property.beds} beds</span>
                        <span>•</span>
                        <span>{property.baths} baths</span>
                      </div>

                      <div className="pt-2 flex items-baseline gap-1">
                        <span className="text-xl font-bold text-primary">
                          ₹{property.price}
                        </span>
                        <span className="text-sm text-muted-foreground">/ night</span>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            ) : (
              <SearchMap properties={properties} favorites={favorites} onToggleFavorite={toggleFavorite} />
            )}

            {/* Load More */}
            {viewMode === "list" && properties.length > 0 && (
              <div className="mt-8 text-center">
                <Button variant="outline" size="lg">
                  Load More Properties
                </Button>
              </div>
            )}

            {/* No Results */}
            {properties.length === 0 && (
              <div className="text-center py-16 space-y-4">
                <div className="w-16 h-16 mx-auto bg-muted rounded-full flex items-center justify-center">
                  <SearchIcon className="w-8 h-8 text-muted-foreground" />
                </div>
                <div className="space-y-2">
                  <h3 className="text-xl font-semibold">No properties found</h3>
                  <p className="text-muted-foreground">
                    Try adjusting your filters or search criteria
                  </p>
                </div>
                <Button onClick={() => setShowFilters(true)}>
                  Adjust Filters
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>

      <SearchFilters 
        open={showFilters} 
        onOpenChange={setShowFilters}
        onFiltersChange={(count) => setActiveFilters(count)}
      />
    </Layout>
  );
};

export default Search;
