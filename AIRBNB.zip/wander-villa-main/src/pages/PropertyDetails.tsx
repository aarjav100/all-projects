import { useState } from "react";
import { useParams, Link } from "react-router-dom";
import Layout from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  Star,
  Heart,
  Share2,
  MapPin,
  Users,
  Bed,
  Bath,
  Wifi,
  Car,
  Droplet,
  Tv,
  Wind,
  Utensils,
  Check,
  X,
  Shield,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";

const PropertyDetails = () => {
  const { id } = useParams();
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [isFavorite, setIsFavorite] = useState(false);

  const property = {
    id: 1,
    title: "Luxury Apartment with Sea View",
    location: "Marine Drive, Mumbai, India",
    price: 15687,
    rating: 4.9,
    reviews: 156,
    images: [
      "https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=800",
      "https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=800",
      "https://images.unsplash.com/photo-1493809842364-78817add7ffb?w=800",
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800",
      "https://images.unsplash.com/photo-1484101403633-562f891dc89a?w=800",
    ],
    host: {
      name: "Sarah Johnson",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100",
      verified: true,
      joinedDate: "2020",
      responseRate: 98,
      responseTime: "within an hour",
    },
    type: "Entire loft",
    guests: 4,
    bedrooms: 2,
    beds: 2,
    bathrooms: 2,
    description:
      "Welcome to this stunning luxury apartment overlooking the Arabian Sea on Mumbai's iconic Marine Drive! This beautifully designed space offers a perfect blend of modern luxury and Indian hospitality, ideal for both business and leisure travelers. The open-concept layout features floor-to-ceiling windows that flood the space with natural light and offer breathtaking sea views. The fully equipped kitchen, comfortable living area, and two spacious bedrooms make this the perfect home away from home.",
    amenities: [
      { icon: Wifi, label: "WiFi", available: true },
      { icon: Car, label: "Free parking", available: true },
      { icon: Droplet, label: "Pool", available: false },
      { icon: Tv, label: "TV", available: true },
      { icon: Wind, label: "Air conditioning", available: true },
      { icon: Utensils, label: "Kitchen", available: true },
    ],
    houseRules: [
      "Check-in: After 3:00 PM",
      "Checkout: Before 11:00 AM",
      "No smoking",
      "No pets allowed",
      "No parties or events",
      "Suitable for children and infants",
    ],
    cancellationPolicy: "Free cancellation up to 48 hours before check-in",
    neighborhood:
      "Located on the iconic Marine Drive, you'll be steps away from Mumbai's best restaurants, shopping districts, and cultural attractions. The Queen's Necklace promenade is perfect for evening walks, and the local train station is just 5 minutes away, providing easy access to all of Mumbai.",
    reviewSummary: {
      cleanliness: 4.9,
      accuracy: 4.8,
      checkin: 5.0,
      communication: 4.9,
      location: 5.0,
      value: 4.7,
    },
  };

  const nextImage = () => {
    setCurrentImageIndex((prev) => (prev + 1) % property.images.length);
  };

  const prevImage = () => {
    setCurrentImageIndex(
      (prev) => (prev - 1 + property.images.length) % property.images.length
    );
  };

  return (
    <Layout showNav={false}>
      <div className="pb-8">
        {/* Header */}
        <div className="bg-card border-b border-border px-4 py-3">
          <div className="max-w-6xl mx-auto flex items-center justify-between">
            <Link to="/search" className="hover:text-primary transition-colors">
              <ChevronLeft className="w-5 h-5" />
            </Link>
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="icon" onClick={() => {}}>
                <Share2 className="w-5 h-5" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsFavorite(!isFavorite)}
              >
                <Heart
                  className={`w-5 h-5 ${
                    isFavorite ? "fill-primary text-primary" : ""
                  }`}
                />
              </Button>
            </div>
          </div>
        </div>

        {/* Image Gallery */}
        <div className="relative aspect-video bg-muted">
          <img
            src={property.images[currentImageIndex]}
            alt={property.title}
            className="w-full h-full object-cover"
          />
          
          <button
            onClick={prevImage}
            className="absolute left-4 top-1/2 -translate-y-1/2 bg-white/90 backdrop-blur-sm rounded-full p-2 hover:bg-white transition-colors"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          
          <button
            onClick={nextImage}
            className="absolute right-4 top-1/2 -translate-y-1/2 bg-white/90 backdrop-blur-sm rounded-full p-2 hover:bg-white transition-colors"
          >
            <ChevronRight className="w-6 h-6" />
          </button>

          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
            {property.images.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentImageIndex(index)}
                className={`w-2 h-2 rounded-full transition-all ${
                  index === currentImageIndex
                    ? "bg-white w-6"
                    : "bg-white/50 hover:bg-white/80"
                }`}
              />
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="px-4 py-6 space-y-6 max-w-6xl mx-auto">
          {/* Title and Rating */}
          <div className="space-y-3">
            <h1 className="text-3xl font-bold">{property.title}</h1>
            <div className="flex flex-wrap items-center gap-4 text-sm">
              <div className="flex items-center gap-1">
                <Star className="w-4 h-4 fill-warning text-warning" />
                <span className="font-semibold">{property.rating}</span>
                <span className="text-muted-foreground">
                  ({property.reviews} reviews)
                </span>
              </div>
              <span className="text-muted-foreground">•</span>
              <div className="flex items-center gap-1 text-muted-foreground">
                <MapPin className="w-4 h-4" />
                <span>{property.location}</span>
              </div>
            </div>
          </div>

          <Separator />

          {/* Host Info */}
          <Card className="p-4">
            <div className="flex items-start gap-4">
              <Avatar className="w-16 h-16">
                <AvatarImage src={property.host.avatar} />
                <AvatarFallback>{property.host.name[0]}</AvatarFallback>
              </Avatar>
              <div className="flex-1 space-y-2">
                <div className="flex items-center gap-2">
                  <h3 className="font-semibold text-lg">{property.host.name}</h3>
                  {property.host.verified && (
                    <Badge variant="secondary" className="gap-1">
                      <Shield className="w-3 h-3" />
                      Verified
                    </Badge>
                  )}
                </div>
                <div className="text-sm text-muted-foreground space-y-1">
                  <p>Joined in {property.host.joinedDate}</p>
                  <p>{property.host.responseRate}% response rate</p>
                  <p>Responds {property.host.responseTime}</p>
                </div>
              </div>
              <Button variant="outline">Contact Host</Button>
            </div>
          </Card>

          {/* Property Details */}
          <div className="space-y-4">
            <h2 className="text-xl font-semibold">Property details</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                <Users className="w-5 h-5 text-muted-foreground" />
                <div>
                  <p className="text-sm text-muted-foreground">Guests</p>
                  <p className="font-semibold">{property.guests}</p>
                </div>
              </div>
              <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                <Bed className="w-5 h-5 text-muted-foreground" />
                <div>
                  <p className="text-sm text-muted-foreground">Bedrooms</p>
                  <p className="font-semibold">{property.bedrooms}</p>
                </div>
              </div>
              <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                <Bed className="w-5 h-5 text-muted-foreground" />
                <div>
                  <p className="text-sm text-muted-foreground">Beds</p>
                  <p className="font-semibold">{property.beds}</p>
                </div>
              </div>
              <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                <Bath className="w-5 h-5 text-muted-foreground" />
                <div>
                  <p className="text-sm text-muted-foreground">Bathrooms</p>
                  <p className="font-semibold">{property.bathrooms}</p>
                </div>
              </div>
            </div>
          </div>

          <Separator />

          {/* Description */}
          <div className="space-y-3">
            <h2 className="text-xl font-semibold">About this place</h2>
            <p className="text-muted-foreground leading-relaxed">
              {property.description}
            </p>
          </div>

          <Separator />

          {/* Amenities */}
          <div className="space-y-4">
            <h2 className="text-xl font-semibold">Amenities</h2>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {property.amenities.map((amenity, index) => {
                const Icon = amenity.icon;
                return (
                  <div
                    key={index}
                    className={`flex items-center gap-3 p-3 rounded-lg ${
                      amenity.available
                        ? "bg-muted/50"
                        : "bg-muted/30 opacity-60"
                    }`}
                  >
                    <Icon className="w-5 h-5 text-muted-foreground" />
                    <span className="text-sm">{amenity.label}</span>
                    {amenity.available ? (
                      <Check className="w-4 h-4 text-success ml-auto" />
                    ) : (
                      <X className="w-4 h-4 text-muted-foreground ml-auto" />
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          <Separator />

          {/* House Rules */}
          <div className="space-y-4">
            <h2 className="text-xl font-semibold">House rules</h2>
            <ul className="space-y-2">
              {property.houseRules.map((rule, index) => (
                <li key={index} className="flex items-center gap-2 text-sm">
                  <Check className="w-4 h-4 text-muted-foreground shrink-0" />
                  <span>{rule}</span>
                </li>
              ))}
            </ul>
          </div>

          <Separator />

          {/* Cancellation Policy */}
          <div className="space-y-3">
            <h2 className="text-xl font-semibold">Cancellation policy</h2>
            <p className="text-muted-foreground">{property.cancellationPolicy}</p>
          </div>

          <Separator />

          {/* Location */}
          <div className="space-y-3">
            <h2 className="text-xl font-semibold">Location</h2>
            <p className="text-muted-foreground">{property.neighborhood}</p>
            <div className="aspect-video bg-muted rounded-lg flex items-center justify-center">
              <MapPin className="w-12 h-12 text-muted-foreground" />
            </div>
          </div>

          {/* Booking Card */}
          <Card className="p-6 sticky bottom-4 shadow-lg">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-baseline gap-1">
                <span className="text-3xl font-bold text-primary">
                  ₹{property.price}
                </span>
                <span className="text-muted-foreground">/ night</span>
              </div>
              <div className="flex items-center gap-1">
                <Star className="w-4 h-4 fill-warning text-warning" />
                <span className="font-semibold">{property.rating}</span>
              </div>
            </div>
            <Button asChild size="lg" className="w-full">
              <Link to={`/booking/${property.id}`}>Book Now</Link>
            </Button>
          </Card>
        </div>
      </div>
    </Layout>
  );
};

export default PropertyDetails;
