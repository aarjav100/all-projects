import Layout from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Search, MapPin, Calendar, Users, Star } from "lucide-react";
import { Link } from "react-router-dom";

const Home = () => {
  const popularDestinations = [
    { name: "Mumbai", country: "India", image: "https://images.unsplash.com/photo-1567157577867-05ccb1388e66?w=400" },
    { name: "Jaipur", country: "India", image: "https://images.unsplash.com/photo-1599661046289-e31897846e41?w=400" },
    { name: "Goa", country: "India", image: "https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?w=400" },
    { name: "Udaipur", country: "India", image: "https://images.unsplash.com/photo-1597074866923-dc0589150358?w=400" },
  ];

  const featuredProperties = [
    {
      id: 1,
      title: "Modern Apartment Near Gateway",
      location: "Mumbai, India",
      price: 9960,
      rating: 4.8,
      reviews: 124,
      image: "https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=400",
    },
    {
      id: 2,
      title: "Luxury Villa with Pool",
      location: "Candolim, Goa",
      price: 20750,
      rating: 4.9,
      reviews: 89,
      image: "https://images.unsplash.com/photo-1582268611958-ebfd161ef9cf?w=400",
    },
  ];

  return (
    <Layout>
      <div className="space-y-8 pb-8">
        {/* Hero Search Section */}
        <section className="bg-gradient-to-br from-primary/10 via-background to-secondary/10 px-6 py-12">
          <div className="max-w-4xl mx-auto space-y-6">
            <div className="text-center space-y-2">
              <h1 className="text-4xl font-bold text-foreground">
                Find your next adventure
              </h1>
              <p className="text-muted-foreground">
                Discover amazing places to stay around the world
              </p>
            </div>

            {/* Search Bar */}
            <Card className="p-6 space-y-4">
              <div className="grid gap-4 md:grid-cols-3">
                <div className="space-y-2">
                  <label className="text-sm font-medium flex items-center gap-2">
                    <MapPin className="w-4 h-4" />
                    Location
                  </label>
                  <Input placeholder="Where are you going?" />
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium flex items-center gap-2">
                    <Calendar className="w-4 h-4" />
                    Check-in / Check-out
                  </label>
                  <Input placeholder="Add dates" type="text" />
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium flex items-center gap-2">
                    <Users className="w-4 h-4" />
                    Guests
                  </label>
                  <Input placeholder="Add guests" type="number" min="1" defaultValue="1" />
                </div>
              </div>
              
              <Button asChild className="w-full" size="lg">
                <Link to="/search">
                  <Search className="w-4 h-4 mr-2" />
                  Search
                </Link>
              </Button>
            </Card>
          </div>
        </section>

        {/* Popular Destinations */}
        <section className="px-6 space-y-4">
          <div className="max-w-6xl mx-auto">
            <h2 className="text-2xl font-bold mb-6">Popular destinations</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {popularDestinations.map((dest) => (
                <Link key={dest.name} to="/search">
                  <Card className="overflow-hidden group cursor-pointer">
                    <div className="aspect-square relative">
                      <img
                        src={dest.image}
                        alt={dest.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                      <div className="absolute bottom-3 left-3 text-white">
                        <p className="font-semibold">{dest.name}</p>
                        <p className="text-sm opacity-90">{dest.country}</p>
                      </div>
                    </div>
                  </Card>
                </Link>
              ))}
            </div>
          </div>
        </section>

        {/* Featured Properties */}
        <section className="px-6 space-y-4">
          <div className="max-w-6xl mx-auto">
            <h2 className="text-2xl font-bold mb-6">Featured properties</h2>
            <div className="grid md:grid-cols-2 gap-6">
              {featuredProperties.map((property) => (
                <Link key={property.id} to={`/property/${property.id}`}>
                  <Card className="overflow-hidden group cursor-pointer">
                    <div className="aspect-video relative">
                      <img
                        src={property.image}
                        alt={property.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                    <div className="p-4 space-y-2">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h3 className="font-semibold text-lg">{property.title}</h3>
                          <p className="text-sm text-muted-foreground">{property.location}</p>
                        </div>
                        <div className="flex items-center gap-1 text-sm">
                          <Star className="w-4 h-4 fill-warning text-warning" />
                          <span className="font-medium">{property.rating}</span>
                          <span className="text-muted-foreground">({property.reviews})</span>
                        </div>
                      </div>
                      <div className="flex items-baseline gap-1">
                        <span className="text-2xl font-bold text-primary">₹{property.price}</span>
                        <span className="text-sm text-muted-foreground">/ night</span>
                      </div>
                    </div>
                  </Card>
                </Link>
              ))}
            </div>
          </div>
        </section>
      </div>
    </Layout>
  );
};

export default Home;
