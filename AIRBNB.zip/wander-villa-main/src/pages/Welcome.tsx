import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const Welcome = () => {
  return (
    <div className="flex flex-col min-h-screen bg-gradient-to-b from-primary/10 to-background">
      <div className="flex-1 flex flex-col items-center justify-center px-6 py-12">
        <div className="w-full max-w-md space-y-8 text-center">
          {/* Logo and Branding */}
          <div className="space-y-3">
            <h1 className="text-5xl font-bold text-primary">searchKaro</h1>
            <p className="text-lg text-muted-foreground">
              Find your perfect stay, anywhere
            </p>
          </div>

          {/* Value Proposition */}
          <div className="space-y-4 py-8">
            <p className="text-base text-foreground">
              Discover unique homes and experiences around the world
            </p>
            <div className="flex items-center justify-center gap-8 text-sm text-muted-foreground">
              <div className="flex flex-col items-center gap-1">
                <span className="text-2xl font-bold text-primary">100K+</span>
                <span>Properties</span>
              </div>
              <div className="flex flex-col items-center gap-1">
                <span className="text-2xl font-bold text-primary">50K+</span>
                <span>Hosts</span>
              </div>
              <div className="flex flex-col items-center gap-1">
                <span className="text-2xl font-bold text-primary">200+</span>
                <span>Countries</span>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="space-y-3">
            <Button asChild size="lg" className="w-full">
              <Link to="/register">Sign Up</Link>
            </Button>
            
            <Button asChild variant="outline" size="lg" className="w-full">
              <Link to="/login">Log In</Link>
            </Button>

            <Button asChild variant="ghost" size="lg" className="w-full">
              <Link to="/">Continue as Guest</Link>
            </Button>
          </div>

          {/* Language Selector */}
          <div className="pt-4">
            <Select defaultValue="en">
              <SelectTrigger className="w-40 mx-auto">
                <SelectValue placeholder="Language" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="en">English</SelectItem>
                <SelectItem value="es">Español</SelectItem>
                <SelectItem value="fr">Français</SelectItem>
                <SelectItem value="hi">हिन्दी</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Welcome;
