import { supabase } from '@/integrations/supabase/client';

/**
 * Profile utility functions that respect RLS policies
 * and handle sensitive data appropriately
 */

export interface PublicProfile {
  id: string;
  first_name: string | null;
  avatar_url: string | null;
  is_verified: boolean | null;
  created_at: string;
}

export interface FullProfile extends PublicProfile {
  last_name: string | null;
  phone: string | null;
  date_of_birth: string | null;
  location: string | null;
  bio: string | null;
  interested_in_hosting: boolean | null;
  updated_at: string;
}

/**
 * Get public profile data (safe for display to other users)
 * Uses secure function to ensure only non-sensitive fields are returned
 */
export async function getPublicProfile(userId: string): Promise<{ data: PublicProfile | null; error: any }> {
  const { data, error } = await supabase
    .rpc('get_public_profile', { profile_id: userId })
    .single();

  return { data, error };
}

/**
 * Get full profile data (only for own profile)
 * Contains sensitive information like phone and date of birth
 */
export async function getOwnProfile(userId: string): Promise<{ data: FullProfile | null; error: any }> {
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', userId)
    .single();

  return { data, error };
}

/**
 * Update own profile
 * Only allows updating own profile data
 */
export async function updateProfile(
  userId: string, 
  updates: Partial<Omit<FullProfile, 'id' | 'created_at' | 'updated_at'>>
) {
  const { data, error } = await supabase
    .from('profiles')
    .update(updates)
    .eq('id', userId)
    .select()
    .single();

  return { data, error };
}

/**
 * Check if current user has a specific role
 */
export async function checkUserRole(role: 'guest' | 'host'): Promise<boolean> {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return false;

  const { data, error } = await supabase.rpc('has_role', {
    _user_id: user.id,
    _role: role
  });

  if (error) {
    console.error('Error checking role:', error);
    return false;
  }

  return data || false;
}
