import { z } from 'zod';

/**
 * Validation schemas for user inputs
 * Prevents injection attacks and ensures data integrity
 */

// Authentication schemas
export const loginSchema = z.object({
  email: z
    .string()
    .trim()
    .email({ message: 'Invalid email address' })
    .max(255, { message: 'Email must be less than 255 characters' }),
  password: z
    .string()
    .min(8, { message: 'Password must be at least 8 characters' })
    .max(100, { message: 'Password must be less than 100 characters' })
});

export const registerSchema = z.object({
  email: z
    .string()
    .trim()
    .email({ message: 'Invalid email address' })
    .max(255, { message: 'Email must be less than 255 characters' }),
  password: z
    .string()
    .min(8, { message: 'Password must be at least 8 characters' })
    .max(100, { message: 'Password must be less than 100 characters' })
    .regex(/[A-Z]/, { message: 'Password must contain at least one uppercase letter' })
    .regex(/[a-z]/, { message: 'Password must contain at least one lowercase letter' })
    .regex(/[0-9]/, { message: 'Password must contain at least one number' }),
  firstName: z
    .string()
    .trim()
    .min(1, { message: 'First name is required' })
    .max(50, { message: 'First name must be less than 50 characters' }),
  lastName: z
    .string()
    .trim()
    .min(1, { message: 'Last name is required' })
    .max(50, { message: 'Last name must be less than 50 characters' }),
  phone: z
    .string()
    .trim()
    .regex(/^[+]?[(]?[0-9]{1,4}[)]?[-\s.]?[(]?[0-9]{1,4}[)]?[-\s.]?[0-9]{1,9}$/, {
      message: 'Invalid phone number format'
    })
    .optional()
});

// Profile update schema
export const profileUpdateSchema = z.object({
  firstName: z
    .string()
    .trim()
    .min(1, { message: 'First name is required' })
    .max(50, { message: 'First name must be less than 50 characters' })
    .optional(),
  lastName: z
    .string()
    .trim()
    .max(50, { message: 'Last name must be less than 50 characters' })
    .optional(),
  bio: z
    .string()
    .trim()
    .max(500, { message: 'Bio must be less than 500 characters' })
    .optional(),
  phone: z
    .string()
    .trim()
    .regex(/^[+]?[(]?[0-9]{1,4}[)]?[-\s.]?[(]?[0-9]{1,4}[)]?[-\s.]?[0-9]{1,9}$/, {
      message: 'Invalid phone number format'
    })
    .optional(),
  location: z
    .string()
    .trim()
    .max(100, { message: 'Location must be less than 100 characters' })
    .optional()
});

// Property listing schema
export const propertySchema = z.object({
  title: z
    .string()
    .trim()
    .min(10, { message: 'Title must be at least 10 characters' })
    .max(100, { message: 'Title must be less than 100 characters' }),
  description: z
    .string()
    .trim()
    .min(50, { message: 'Description must be at least 50 characters' })
    .max(2000, { message: 'Description must be less than 2000 characters' }),
  address: z
    .string()
    .trim()
    .min(5, { message: 'Address is required' })
    .max(200, { message: 'Address must be less than 200 characters' }),
  city: z
    .string()
    .trim()
    .min(2, { message: 'City is required' })
    .max(100, { message: 'City must be less than 100 characters' }),
  country: z
    .string()
    .trim()
    .min(2, { message: 'Country is required' })
    .max(100, { message: 'Country must be less than 100 characters' }),
  pricePerNight: z
    .number()
    .positive({ message: 'Price must be positive' })
    .max(100000, { message: 'Price seems unreasonably high' }),
  maxGuests: z
    .number()
    .int()
    .positive({ message: 'Must accommodate at least 1 guest' })
    .max(50, { message: 'Maximum 50 guests allowed' }),
  bedrooms: z
    .number()
    .int()
    .nonnegative({ message: 'Bedrooms cannot be negative' })
    .max(50, { message: 'Maximum 50 bedrooms' }),
  beds: z
    .number()
    .int()
    .positive({ message: 'Must have at least 1 bed' })
    .max(100, { message: 'Maximum 100 beds' }),
  bathrooms: z
    .number()
    .positive({ message: 'Must have at least 1 bathroom' })
    .max(50, { message: 'Maximum 50 bathrooms' })
});

// Booking schema
export const bookingSchema = z.object({
  checkInDate: z.date(),
  checkOutDate: z.date(),
  guestCount: z
    .number()
    .int()
    .positive({ message: 'Must have at least 1 guest' })
    .max(50, { message: 'Maximum 50 guests' }),
  specialRequests: z
    .string()
    .trim()
    .max(1000, { message: 'Special requests must be less than 1000 characters' })
    .optional()
}).refine(
  (data) => data.checkOutDate > data.checkInDate,
  { message: 'Check-out date must be after check-in date', path: ['checkOutDate'] }
);

// Message schema
export const messageSchema = z.object({
  content: z
    .string()
    .trim()
    .min(1, { message: 'Message cannot be empty' })
    .max(2000, { message: 'Message must be less than 2000 characters' })
});

// Review schema
export const reviewSchema = z.object({
  rating: z
    .number()
    .int()
    .min(1, { message: 'Rating must be at least 1' })
    .max(5, { message: 'Rating must be at most 5' }),
  comment: z
    .string()
    .trim()
    .min(10, { message: 'Review must be at least 10 characters' })
    .max(1000, { message: 'Review must be less than 1000 characters' })
    .optional(),
  cleanlinessRating: z.number().int().min(1).max(5).optional(),
  accuracyRating: z.number().int().min(1).max(5).optional(),
  communicationRating: z.number().int().min(1).max(5).optional(),
  locationRating: z.number().int().min(1).max(5).optional(),
  valueRating: z.number().int().min(1).max(5).optional()
});

// Search query schema
export const searchSchema = z.object({
  location: z
    .string()
    .trim()
    .min(2, { message: 'Location must be at least 2 characters' })
    .max(100, { message: 'Location must be less than 100 characters' }),
  checkIn: z.date().optional(),
  checkOut: z.date().optional(),
  guests: z
    .number()
    .int()
    .positive()
    .max(50)
    .optional(),
  minPrice: z.number().nonnegative().optional(),
  maxPrice: z.number().positive().optional()
}).refine(
  (data) => !data.checkOut || !data.checkIn || data.checkOut > data.checkIn,
  { message: 'Check-out must be after check-in', path: ['checkOut'] }
);

// Support ticket schema
export const supportTicketSchema = z.object({
  name: z
    .string()
    .trim()
    .min(1, { message: 'Name is required' })
    .max(100, { message: 'Name must be less than 100 characters' }),
  email: z
    .string()
    .trim()
    .email({ message: 'Invalid email address' })
    .max(255, { message: 'Email must be less than 255 characters' }),
  subject: z
    .string()
    .trim()
    .min(1, { message: 'Subject is required' })
    .max(200, { message: 'Subject must be less than 200 characters' }),
  message: z
    .string()
    .trim()
    .min(10, { message: 'Message must be at least 10 characters' })
    .max(2000, { message: 'Message must be less than 2000 characters' })
});
