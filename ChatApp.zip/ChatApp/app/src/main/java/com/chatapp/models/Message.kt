package com.chatapp.models

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Message(
    val id: String = "",
    val senderId: String = "",
    val receiverId: String = "",
    val message: String = "",
    val imageUrl: String = "",
    val timestamp: Long = 0L,
    val isRead: Boolean = false,
    val messageType: MessageType = MessageType.TEXT
) : Parcelable {
    
    // No-argument constructor for Firebase
    constructor() : this("", "", "", "", "", 0L, false, MessageType.TEXT)
    
    fun toMap(): HashMap<String, Any> {
        return hashMapOf(
            "id" to id,
            "senderId" to senderId,
            "receiverId" to receiverId,
            "message" to message,
            "imageUrl" to imageUrl,
            "timestamp" to timestamp,
            "isRead" to isRead,
            "messageType" to messageType.name
        )
    }
}

enum class MessageType {
    TEXT,
    IMAGE
}

