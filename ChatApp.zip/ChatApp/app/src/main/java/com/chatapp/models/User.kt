package com.chatapp.models

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class User(
    val uid: String = "",
    val name: String = "",
    val email: String = "",
    val profileImageUrl: String = "",
    val isOnline: Boolean = false,
    val lastSeen: Long = 0L,
    val fcmToken: String = ""
) : Parcelable {
    
    // No-argument constructor for Firebase
    constructor() : this("", "", "", "", false, 0L, "")
    
    fun toMap(): HashMap<String, Any> {
        return hashMapOf(
            "uid" to uid,
            "name" to name,
            "email" to email,
            "profileImageUrl" to profileImageUrl,
            "isOnline" to isOnline,
            "lastSeen" to lastSeen,
            "fcmToken" to fcmToken
        )
    }
}

