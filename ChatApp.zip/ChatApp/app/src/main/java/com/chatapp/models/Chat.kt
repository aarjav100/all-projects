package com.chatapp.models

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Chat(
    val chatId: String = "",
    val participants: List<String> = emptyList(),
    val lastMessage: String = "",
    val lastMessageTime: Long = 0L,
    val lastMessageSenderId: String = "",
    val unreadCount: Int = 0
) : Parcelable {
    
    // No-argument constructor for Firebase
    constructor() : this("", emptyList(), "", 0L, "", 0)
    
    fun toMap(): HashMap<String, Any> {
        return hashMapOf(
            "chatId" to chatId,
            "participants" to participants,
            "lastMessage" to lastMessage,
            "lastMessageTime" to lastMessageTime,
            "lastMessageSenderId" to lastMessageSenderId,
            "unreadCount" to unreadCount
        )
    }
    
    fun getOtherParticipant(currentUserId: String): String {
        return participants.firstOrNull { it != currentUserId } ?: ""
    }
}

